---
name: software-architecture-ai-scientist
description: >
  An experimental software architecture and engineering skill inspired by Sakana AI's
  AI Scientist and AI Scientist-v2. It treats architecture proposals as falsifiable hypotheses,
  performs novelty and prior-art review, explores competing designs through budgeted agentic tree
  search, implements isolated prototypes, executes controlled experiments, analyzes results,
  produces evidence-backed architecture decisions, and subjects them to simulated peer review.
  Use for difficult architecture decisions, modernization experiments, performance and resiliency
  engineering, platform design, technology evaluation, production optimization, and repository-aware
  engineering research.
version: 1.0.0
license: MIT
tags:
  - ai-scientist
  - agentic-tree-search
  - software-architecture
  - experimental-engineering
  - hypothesis-driven-development
  - repository-analysis
  - benchmarking
  - architecture-decision
  - verification
---

# Software Architecture and Engineering AI Scientist

## 1. Mission

Turn consequential software architecture and engineering questions into controlled, reproducible
engineering research.

This skill does not merely produce an architecture opinion. It:

1. formulates testable architecture hypotheses;
2. checks whether the idea is actually new or already covered by local patterns, prior decisions,
   standards, products, or known techniques;
3. explores multiple candidate designs using progressive agentic tree search;
4. implements bounded prototypes or repository changes in isolated workspaces;
5. executes experiments and records artifacts;
6. analyzes results and uncertainty;
7. writes an evidence-backed architecture research report;
8. runs an independent simulated architecture peer review;
9. iterates until the design meets acceptance thresholds or the budget is exhausted;
10. converts the accepted hypothesis into a production delivery plan.

The preferred operating model follows AI Scientist-v2. The v1-style linear workflow remains available
for constrained tasks.

---

## 2. Conceptual Translation

| AI Scientist / AI Scientist-v2 | Software Architecture AI Scientist |
|---|---|
| Research topic | Engineering mission |
| Research idea | Architecture or engineering hypothesis |
| Novelty search | Prior-art, repository-pattern, ADR, vendor, and standards review |
| Code template / experimental codebase | Existing repository, sandbox, benchmark harness, or generated spike |
| Experiment | Prototype, benchmark, fault injection, security test, migration rehearsal |
| Experiment manager | Architecture Experiment Manager |
| Agentic tree search | Branching exploration of design and implementation variants |
| Metrics and plots | Quality-attribute measurements and architecture visualizations |
| Scientific paper | Architecture Research Report and ADR package |
| Automated reviewer | Architecture Peer-Review Council |
| Review score and feedback | Decision fitness score, blocking concerns, and revision request |
| Open-ended iteration | Architecture learning loop and reusable experiment memory |

---

## 3. Appropriate Uses

Use for:

- difficult architecture choices with meaningful uncertainty;
- comparing architectural patterns or platform technologies;
- modernization and decomposition hypotheses;
- performance, scalability, and cost optimization;
- resiliency and disaster-recovery design;
- API, event, caching, data, or consistency strategies;
- security architecture controls that can be tested;
- developer-platform or software-factory design;
- migration feasibility and compatibility experiments;
- recurring production problems with competing causal theories;
- repository-specific architecture evolution;
- evaluating whether an enterprise standard fits a product.

Use a simpler design workflow when the correct choice is already established and no experiment would
materially reduce uncertainty.

---

## 4. Non-Negotiable Safety Boundary

Autonomous experimentation must be sandboxed.

The skill MUST NOT:

- run destructive experiments against production;
- access secrets beyond explicit test credentials;
- exfiltrate source, data, logs, or artifacts;
- mutate protected branches or shared environments without authorization;
- generate uncontrolled cloud cost;
- perform denial-of-service testing against live systems;
- weaken tests or controls to improve a score;
- claim novelty, correctness, or production readiness without evidence;
- fabricate experiment output;
- silently alter the experiment objective after seeing results;
- promote a prototype directly to production.

Experiments involving destructive migration, security exploitation, personal data, regulated data,
irreversible infrastructure, or external systems require an explicit human gate.

---

# 5. Operating Modes

## 5.1 AI Scientist-v2 Tree-Search Mode

Default for open-ended or high-uncertainty work.

Uses progressive branching, experiment-manager control, checkpointing, pruning, and branch promotion.

## 5.2 AI Scientist-v1 Linear Mode

Use when:

- the repository has a known experimental scaffold;
- only a few variants are viable;
- the metric and acceptance threshold are clear;
- cost and time are tightly constrained.

Flow:

```text
Idea → novelty review → implement → experiment → analyze → report → review → revise
```

## 5.3 Architecture Spike Mode

Produces bounded proof-of-concept evidence without a production implementation.

## 5.4 Production Optimization Mode

Starts from an observed baseline and searches for a measurable improvement while preserving specified
invariants.

## 5.5 Incident Hypothesis Mode

Branches over competing causal and remediation hypotheses and attempts to reproduce or falsify them.

## 5.6 Human-Guided Mode

The human controls branch promotion, experiment budget, risk acceptance, and final architecture choice.

---

# 6. Lifecycle

## Phase 0 — Establish the Research Charter

Create:

```yaml
research_charter:
  mission:
  problem_statement:
  desired_outcomes:
  baseline:
  scope:
  exclusions:
  stakeholders:
  decision_owner:
  target_system:
  quality_attributes:
  invariants:
  constraints:
  experiment_budget:
    max_branches:
    max_depth:
    max_runtime:
    max_compute_cost:
    max_external_calls:
  authorized_environments:
  prohibited_actions:
  success_thresholds:
  termination_conditions:
  required_deliverables:
```

### Outcome and metric discipline

Every desired outcome needs at least one observable measure or defensible qualitative rubric.

Examples:

| Outcome | Measure |
|---|---|
| Lower latency | p50, p95, p99 under declared workload |
| Higher resilience | recovery time, error budget impact, successful fault scenarios |
| Lower coupling | dependency violations, change propagation, independent deployment evidence |
| Safer supply chain | blocked malicious cases, false-positive rate, provenance completeness |
| Better developer experience | setup time, build time, task success, cognitive complexity proxy |
| Lower cost | cost per request, workload, tenant, or build |
| Easier change | lead time, affected modules, compatibility window |

### Gate R0

Do not proceed when:

- the hypothesis cannot be tested;
- no safe environment exists;
- the metric can be trivially gamed;
- required invariants are missing;
- the experiment budget is undefined for autonomous mode.

---

## Phase 1 — Repository and System Baseline

The Baseline Scientist maps:

- languages, frameworks, and versions;
- repository and build topology;
- deployable units;
- critical execution paths;
- APIs, events, schemas, and consumers;
- state ownership;
- infrastructure and deployment;
- trust and fault boundaries;
- tests and quality gates;
- telemetry and SLOs;
- historical incidents and hotspots;
- cost and capacity evidence;
- existing ADRs and standards.

Create a baseline that can be reproduced.

```yaml
baseline:
  commit_or_artifact:
  environment:
  configuration:
  dataset_or_workload:
  commands:
  metrics:
  results:
  artifacts:
  known_noise:
  confidence:
```

No proposed branch may compare itself against an undefined or shifting baseline.

---

## Phase 2 — Generate Architecture Hypotheses

The Idea Scientist generates candidate hypotheses, not generic recommendations.

### Hypothesis schema

```yaml
hypothesis:
  id:
  title:
  claim:
  mechanism:
  affected_components:
  expected_outcomes:
  measurable_predictions:
  invariants:
  assumptions:
  risks:
  experiment:
  minimal_falsifier:
  estimated_cost:
  novelty_status:
  status:
```

A good hypothesis has:

- a causal mechanism;
- measurable predictions;
- conditions under which it fails;
- a minimal experiment;
- identified trade-offs;
- no dependence on invented repository facts.

### Examples

Weak:

```text
Kafka will make the system more scalable.
```

Testable:

```text
Replacing synchronous fan-out from the order service with a durable event log and independently
scaled consumers will keep order-acceptance p99 below 300 ms at 4× current peak load while preserving
at-least-once processing, idempotent effects, and a recovery point objective of zero acknowledged
orders.
```

Generate:

- conservative/evolutionary hypotheses;
- strategic hypotheses;
- counterintuitive hypotheses;
- “do nothing / tune existing design” hypotheses;
- disconfirming hypotheses.

---

## Phase 3 — Novelty and Prior-Art Review

Architecture novelty does not mean academic originality alone. Determine whether the proposal is:

- already implemented in the repository;
- previously accepted or rejected in an ADR;
- available through an existing enterprise platform;
- required or prohibited by a standard;
- a known architecture pattern;
- a vendor capability;
- a known failed experiment;
- materially different only in naming;
- novel in this system because of a new combination or constraint.

### Sources

1. source and configuration;
2. Git history;
3. ADRs, RFCs, diagrams, and issue records;
4. internal standards and reference architectures;
5. platform and product catalogs;
6. official technical documentation;
7. standards and research literature;
8. incident and experiment archives.

### Novelty decision

```yaml
novelty_review:
  hypothesis_id:
  classification:
    - duplicate
    - known-pattern
    - local-application-new
    - novel-combination
    - materially-novel
    - uncertain
  nearest_prior_art:
  differentiators:
  prior_failures:
  evidence_ids:
  confidence:
  action:
```

Do not discard a non-novel idea when it remains the best engineering choice. Novelty is a search and
learning signal, not the primary value criterion.

### Gate R1

A hypothesis may proceed when it:

- is not a pointless duplicate;
- has a repository-specific question worth testing;
- has defensible differentiation or application value;
- has sufficient evidence to design an experiment.

---

## Phase 4 — Initialize the Agentic Experiment Tree

AI Scientist-v2 replaces a single fixed path with progressive tree search.

### Node schema

```yaml
experiment_node:
  id:
  parent_id:
  depth:
  hypothesis_id:
  branch_intent:
  design_variant:
  implementation_state:
  experiment_plan:
  predicted_result:
  actual_result:
  score:
  uncertainty:
  cost:
  risks:
  artifacts:
  reviewer_feedback:
  status:
    - proposed
    - approved
    - running
    - completed
    - failed
    - pruned
    - promoted
    - archived
```

### Root

The root contains:

- baseline;
- mission;
- quality attributes;
- invariants;
- initial evidence;
- budget.

### Branch operations

- **Expand:** create distinct child variants.
- **Refine:** improve the same mechanism.
- **Mutate:** alter one design dimension.
- **Combine:** merge compatible successful features.
- **Replicate:** repeat to test stability.
- **Challenge:** create a branch intended to falsify another.
- **Prune:** stop low-value branches.
- **Promote:** advance strong evidence to deeper testing.
- **Backtrack:** return to a prior node after failure.

### Branch diversity dimensions

- component boundary;
- interaction style;
- data and consistency model;
- algorithm;
- concurrency model;
- cache or state strategy;
- deployment topology;
- resilience mechanism;
- security control;
- migration strategy;
- operational model;
- build or runtime technology.

Do not create superficial branches that differ only by naming or formatting.

---

## Phase 5 — Architecture Experiment Manager

The Experiment Manager controls search rather than implementing every branch itself.

### Responsibilities

- choose the next node;
- allocate compute and time;
- enforce safety and invariants;
- balance exploration and exploitation;
- detect duplicate branches;
- stop non-informative work;
- require checkpoint artifacts;
- compare branches against baseline;
- request replication;
- route failures to diagnosis;
- preserve negative results;
- promote only evidence-backed branches.

### Node selection score

A host may estimate:

```text
selection_score =
  expected_information_gain
  + outcome_upside
  + uncertainty_reduction
  + branch_diversity
  + reversibility
  - estimated_cost
  - safety_risk
  - duplication
  - invariant_risk
```

### Progressive depth

Suggested stages:

1. **D0 — Paper design:** static architecture analysis.
2. **D1 — Micro-spike:** smallest code/configuration proof.
3. **D2 — Component experiment:** realistic isolated component.
4. **D3 — Integration experiment:** multiple real dependencies.
5. **D4 — System benchmark:** production-like workload or fault model.
6. **D5 — Migration/recovery rehearsal:** rollout and rollback proof.

A weak branch should fail cheaply at shallow depth.

### Experiment budget policy

Reserve budget for:

- at least one conservative branch;
- at least one challenge branch;
- replication of finalists;
- independent review;
- unexpected failures.

---

## Phase 6 — Design Reproducible Experiments

Each experiment must include:

```yaml
experiment:
  id:
  node_id:
  question:
  hypothesis:
  independent_variables:
  controlled_variables:
  workload_or_dataset:
  environment:
  baseline_reference:
  implementation_steps:
  commands:
  metrics:
  thresholds:
  repetitions:
  expected_result:
  falsification_condition:
  safety_controls:
  cleanup:
  artifacts:
```

### Experiment categories

- static architecture fitness test;
- dependency and modularity test;
- API/event contract test;
- benchmark;
- load, stress, spike, or soak test;
- fault injection;
- recovery and rollback rehearsal;
- security-control test;
- migration simulation;
- cost model;
- developer workflow study;
- compatibility matrix;
- data consistency experiment;
- prototype usability evaluation.

### Experimental validity

Control:

- workload changes;
- environment drift;
- warm-up effects;
- caching state;
- random seeds;
- test-data changes;
- infrastructure noise;
- compiler/runtime versions;
- benchmark observer effects;
- measurement overhead.

State when a result is directional rather than statistically strong.

---

## Phase 7 — Implement in Isolated Research Workspaces

Each branch uses an isolated worktree, branch, container, namespace, or ephemeral environment.

### Branch workspace contract

```yaml
workspace:
  branch_or_worktree:
  base_commit:
  owned_paths:
  prohibited_paths:
  environment:
  secrets_policy:
  network_policy:
  resource_limits:
  cleanup_policy:
```

### Implementation rules

1. Inspect relevant code before editing.
2. Preserve an untouched baseline.
3. Change one principal variable per experiment where practical.
4. Record every command and configuration.
5. Do not weaken tests.
6. Keep instrumentation needed to explain results.
7. Commit branch state at experiment checkpoints.
8. Record failed builds and runtime errors as results.
9. Clean up ephemeral resources.
10. Never merge an experimental branch automatically.

AI Scientist-v2 does not require a human-authored code template; similarly, this skill may construct its
own experiment scaffold. It must still conform to repository standards and safety limits.

---

## Phase 8 — Execute and Observe

The Experiment Runner:

- validates environment and budget;
- runs baseline when required;
- executes branch experiment;
- captures stdout, stderr, exit status, timing, resource use, and test artifacts;
- gathers metrics, traces, profiles, and security outputs;
- generates visualizations when useful;
- records anomalies;
- performs cleanup;
- updates the tree.

### Result schema

```yaml
result:
  experiment_id:
  status:
  started_at:
  ended_at:
  environment_fingerprint:
  commands:
  metrics:
  confidence_intervals_or_variance:
  failures:
  anomalies:
  invariant_violations:
  artifacts:
  cost:
  reproducibility_status:
```

Failed execution is not automatically a failed hypothesis. Classify:

- implementation failure;
- environment failure;
- measurement failure;
- hypothesis falsification;
- invariant violation;
- budget exhaustion;
- inconclusive result.

---

## Phase 9 — Analyze Results and Produce Visual Evidence

The Analysis Scientist compares:

- branch versus baseline;
- branch versus sibling;
- expected versus actual;
- average versus tail behavior;
- benefit versus operational complexity;
- benefit versus migration risk;
- result versus invariant;
- result robustness across repetitions.

### Required analysis

- effect size or material difference;
- variance and uncertainty;
- confounders;
- failure cases;
- negative results;
- sensitivity;
- reproducibility;
- limitations;
- implications for deeper experiments.

### Visualization review

Use architecture diagrams, dependency graphs, flame graphs, latency distributions, throughput curves,
cost curves, failure timelines, and migration state diagrams where they improve interpretation.

Inspired by AI Scientist-v2's visual-feedback loop, a Diagram and Visualization Reviewer checks:

- whether labels are legible;
- whether scales and units are correct;
- whether the diagram matches evidence;
- whether comparisons are misleading;
- whether visual clutter hides the conclusion;
- whether generated views omit critical boundaries;
- whether captions state the actual takeaway.

A polished visualization must not compensate for weak evidence.

---

## Phase 10 — Score, Prune, Promote, and Iterate

### Node fitness dimensions

| Dimension | Question |
|---|---|
| Outcome | Did it improve the target outcome? |
| Invariants | Were required properties preserved? |
| Evidence | Is the result reproducible and well-supported? |
| Simplicity | Is complexity proportionate to benefit? |
| Operability | Can it be deployed, observed, supported, and recovered? |
| Security | Does it reduce or introduce material risk? |
| Migration | Can it be adopted safely and incrementally? |
| Cost | Is the benefit worth implementation and runtime cost? |
| Changeability | Does it improve or impair future evolution? |
| Confidence | How robust is the conclusion? |

### Promotion rules

Promote when:

- benefit exceeds threshold;
- no blocking invariant is violated;
- result is reproducible enough for the current depth;
- the next experiment meaningfully reduces decision uncertainty;
- branch cost remains within budget.

### Pruning rules

Prune when:

- the core mechanism is falsified;
- an invariant is irreconcilably violated;
- the branch duplicates stronger evidence;
- expected upside is too small;
- operational cost dominates;
- deeper testing would not alter the decision;
- safety or budget boundary is reached.

Never delete negative results. Archive them as reusable engineering knowledge.

---

## Phase 11 — Write the Architecture Research Report

The Report Scientist produces:

```markdown
# Architecture Research Report

## Abstract
## Engineering Mission
## Current-State Baseline
## Prior Art and Novelty Review
## Hypotheses
## Agentic Experiment Tree
## Experimental Methods
## Results
## Architecture and Visual Evidence
## Analysis and Limitations
## Competing Explanations
## Recommended Architecture
## Rejected and Archived Branches
## Security, Resiliency, and Operability
## Migration and Delivery Plan
## Verification and Reproducibility
## Residual Risks and Open Questions
## ADRs
## Evidence and Artifact Register
```

### Report discipline

- Never invent numbers.
- Link every numerical claim to an artifact.
- Separate evidence from interpretation.
- Include failed and inconclusive experiments.
- Explain why branches were pruned.
- State limitations prominently.
- Avoid overstating novelty.
- Do not imply production validity from a shallow spike.

---

## Phase 12 — Simulated Architecture Peer Review

Use an independent review context that did not manage the experiments.

### Review council

- Principal Architecture Reviewer
- Domain Reviewer
- Security Reviewer
- Reliability/SRE Reviewer
- Data/Integration Reviewer
- Delivery and Migration Reviewer
- Experimental-Method Reviewer
- Skeptical Maintainer
- Optional executive/value reviewer

### Review criteria

Score 1–10:

1. Problem significance
2. Baseline quality
3. Prior-art completeness
4. Hypothesis clarity
5. Experimental validity
6. Evidence sufficiency
7. Architecture correctness
8. Security and resilience
9. Operability and maintainability
10. Migration feasibility
11. Reproducibility
12. Clarity of report and visuals

### Review outcome

```yaml
peer_review:
  recommendation:
    - accept
    - accept-with-conditions
    - major-revision
    - reject
    - insufficient-evidence
  scores:
  blocking_concerns:
  non_blocking_concerns:
  required_experiments:
  required_design_changes:
  confidence:
```

### Reviewer guardrail

The reviewer must challenge:

- metric gaming;
- cherry-picked results;
- missing baselines;
- shallow experiments;
- untested failure behavior;
- hidden operational burden;
- unsupported novelty;
- ignored negative results;
- diagrams inconsistent with implementation;
- conclusions that exceed evidence.

---

## Phase 13 — Revision Loop

Reviewer feedback creates new tree nodes.

Examples:

- replicate with a different workload;
- add a conservative comparison;
- test a failure mode;
- revise a component boundary;
- analyze cost sensitivity;
- conduct rollback rehearsal;
- add a security-control experiment;
- simplify the design;
- correct a misleading visualization.

The Experiment Manager decides whether to:

- reopen a pruned branch;
- refine a finalist;
- add a challenge branch;
- terminate with insufficient evidence;
- request a human decision;
- accept with conditions.

Stop when:

- acceptance threshold is met;
- decision uncertainty is low enough;
- remaining uncertainty requires production evidence unavailable in the sandbox;
- budget is exhausted;
- no viable hypothesis remains;
- the human ends the research.

---

## Phase 14 — Convert the Accepted Hypothesis into Production Engineering

An accepted research branch is not production-ready by default.

Create change units:

```yaml
change_unit:
  id:
  accepted_node:
  outcome:
  scope:
  owner:
  files_or_modules:
  interfaces:
  dependencies:
  implementation_steps:
  architecture_invariants:
  tests:
  controls:
  observability:
  rollout:
  rollback_and_recovery:
  acceptance_criteria:
  experiment_evidence:
  residual_risk:
```

### Productionization gap analysis

Assess:

- prototype shortcuts;
- test completeness;
- security hardening;
- data migration;
- backward compatibility;
- capacity and cost;
- operational ownership;
- SLO and alerting;
- support and runbooks;
- CI/CD and policy controls;
- disaster recovery;
- deprecation and cleanup.

Use expand–migrate–contract and progressive delivery where applicable.

---

## Phase 15 — Post-Deployment Learning Loop

After authorized deployment:

- compare production behavior with experiment prediction;
- detect distribution or workload shift;
- record incidents and unexpected effects;
- update confidence;
- revise architecture fitness functions;
- add reusable results to memory;
- reopen the hypothesis when revisit triggers occur.

The system becomes an evolutionary architecture laboratory rather than a one-time report generator.

---

# 7. Agent Roles

## Research Director

Owns mission, human gates, scope, and termination.

## Idea Scientist

Generates falsifiable architecture hypotheses.

## Prior-Art Scientist

Searches repository history, ADRs, patterns, standards, products, and literature.

## Baseline Scientist

Creates a reproducible current-state measurement.

## Architecture Experiment Manager

Runs progressive agentic tree search and budget allocation.

## Implementation Scientist

Builds isolated prototypes and changes.

## Experiment Runner

Executes controlled experiments and captures artifacts.

## Analysis Scientist

Evaluates effect, uncertainty, confounders, and limitations.

## Visualization Scientist

Produces evidence-aligned diagrams and plots.

## Reproducibility Auditor

Attempts to rerun finalists independently.

## Report Scientist

Writes the architecture research report.

## Architecture Peer-Review Council

Critiques the work independently.

## Productionization Lead

Converts accepted evidence into safe delivery increments.

---

# 8. Required Artifacts

```text
architecture-research/
├── charter.yaml
├── baseline/
│   ├── baseline.yaml
│   └── artifacts/
├── prior-art/
│   └── novelty-review.yaml
├── hypotheses/
│   └── H-*.yaml
├── tree/
│   ├── experiment-tree.yaml
│   └── checkpoints/
├── experiments/
│   └── X-*/
│       ├── experiment.yaml
│       ├── result.yaml
│       ├── logs/
│       └── artifacts/
├── analysis/
│   ├── branch-comparison.md
│   └── visualizations/
├── reviews/
│   ├── peer-review-*.md
│   └── revisions.yaml
├── decisions/
│   └── ADR-*.md
├── delivery/
│   └── change-units/
├── report.md
└── research-memory.yaml
```

---

# 9. Research Memory

Store:

### Episodic

- experiment attempt;
- branch history;
- failure;
- reviewer feedback;
- human decision;
- production outcome.

### Semantic

- stable system facts;
- quality-attribute relationships;
- validated architectural mechanisms;
- dependency and interface knowledge.

### Procedural

- benchmark methods;
- test harnesses;
- migration recipes;
- failure-injection procedures;
- review rubrics.

### Negative-result memory

- rejected hypothesis;
- failed mechanism;
- conditions of failure;
- evidence;
- whether it may become viable under different constraints.

Negative results prevent repeated architectural rediscovery.

---

# 10. Quality Gates

## Q0 — Charter

Testable mission, invariants, safe environment, and budget.

## Q1 — Baseline

Reproducible baseline with declared noise and artifacts.

## Q2 — Prior art

Nearest alternatives and local history reviewed.

## Q3 — Hypothesis

Causal, falsifiable, measurable, and bounded.

## Q4 — Experiment

Controlled, safe, reproducible, and linked to a decision.

## Q5 — Evidence

Results are real, complete, uncertainty-aware, and not cherry-picked.

## Q6 — Architecture

Recommendation accounts for security, resilience, data, operation, and migration.

## Q7 — Peer review

Independent blocking concerns resolved or explicitly accepted.

## Q8 — Productionization

Prototype-to-production gaps have owners and change units.

A failed gate causes revision, rejection, or an explicit human exception.

---

# 11. Default Invocation Prompt

```text
Run the Software Architecture and Engineering AI Scientist using AI Scientist-v2 tree-search mode.

Treat architecture choices as falsifiable hypotheses. Establish a reproducible repository and runtime
baseline, review prior art and local architectural history, generate conservative and ambitious
hypotheses, and explore them through budgeted progressive agentic tree search. Use an Architecture
Experiment Manager to expand, refine, challenge, replicate, prune, and promote branches.

Implement experiments only in authorized isolated workspaces. Capture exact commands, environments,
metrics, failures, artifacts, cost, and uncertainty. Preserve negative and inconclusive results.
Generate evidence-aligned architecture visualizations and subject them to visual review. Write an
Architecture Research Report and run an independent simulated Architecture Peer Review. Convert only
accepted or conditionally accepted hypotheses into production change units.

Never fabricate results, claim novelty without review, weaken controls, run unsafe production
experiments, or equate a successful prototype with production readiness.

Mission:
{{MISSION}}

Repositories and context:
{{CONTEXT}}

Quality attributes and invariants:
{{QUALITY_ATTRIBUTES_AND_INVARIANTS}}

Authorized environments and safety constraints:
{{SAFETY}}

Experiment budget:
{{BUDGET}}

Requested deliverables:
{{DELIVERABLES}}
```

---

# 12. Provenance and Adaptation Notes

This is an independent software-engineering adaptation inspired by Sakana AI's AI Scientist and
AI Scientist-v2.

AI Scientist introduced an end-to-end loop that generates ideas, checks novelty, writes and executes
experimental code, visualizes results, writes a paper, and runs an automated review. AI Scientist-v2
generalized the approach beyond human-authored templates and introduced progressive agentic tree search
managed by an experiment manager, along with iterative visual feedback.

This package adopts those workflow concepts but does not claim scientific novelty, autonomous
production authority, or equivalence to Sakana AI's implementation.

Primary sources:

- SakanaAI/AI-Scientist, official repository.
- Chris Lu et al., “The AI Scientist: Towards Fully Automated Open-Ended Scientific Discovery,”
  arXiv:2408.06292.
- SakanaAI/AI-Scientist-v2, official repository.
- Yutaro Yamada et al., “The AI Scientist-v2: Workshop-Level Automated Scientific Discovery via
  Agentic Tree Search,” arXiv:2504.08066.
