# Experiment

- **ID:**
- **Tree node:**
- **Question:**
- **Hypothesis:**
- **Baseline reference:**

## Variables

## Environment and fingerprint

## Workload/data

## Implementation

## Commands

## Metrics and thresholds

## Repetitions

## Expected result

## Falsification condition

## Safety and cleanup

# Result

- **Status:**
- **Start/end:**
- **Exit state:**

## Raw metrics

## Variance/uncertainty

## Failures and anomalies

## Invariant violations

## Cost

## Artifacts

## Reproducibility status

## Interpretation

## Threats to validity
