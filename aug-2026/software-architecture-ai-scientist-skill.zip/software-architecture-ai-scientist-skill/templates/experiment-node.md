# Experiment Tree Node

- **Node ID:**
- **Parent:**
- **Depth:**
- **Hypothesis:**
- **Status:**
- **Branch intent:** expand | refine | mutate | combine | replicate | challenge
- **Workspace:**

## Design variant

## Prediction

## Experiment plan

## Actual result

## Metrics and uncertainty

## Invariant status

## Cost

## Artifacts

## Failure classification

## Reviewer feedback

## Manager decision

Promote | Refine | Replicate | Challenge | Prune | Archive

## Decision rationale
