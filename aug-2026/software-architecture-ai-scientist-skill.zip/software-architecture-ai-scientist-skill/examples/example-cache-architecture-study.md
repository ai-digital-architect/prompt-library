# Example: Cache Architecture AI Scientist Study

## Mission

Reduce product-catalog read p99 from 900 ms to below 250 ms at 5× peak traffic without serving data
older than 60 seconds, increasing error rate, or creating an unrecoverable cache dependency.

## Baseline

- synchronous database reads;
- p99 900 ms under declared workload;
- database CPU 82%;
- no cache;
- test environment and dataset fingerprint recorded.

## Initial hypotheses

### H1 — Query and index optimization
A conservative branch predicts p99 below 500 ms with no new runtime dependency.

### H2 — Local in-process cache
Predicts p99 below 200 ms but may create inconsistent per-instance state and cold-start effects.

### H3 — Distributed read-through cache
Predicts p99 below 250 ms and database CPU below 45%, with explicit stale-data and outage behavior.

### H4 — Precomputed read model
Predicts strongest scale characteristics but adds event processing and migration complexity.

## Tree behavior

- D1 spikes prune a poorly performing serialization variant.
- H1 is retained as a low-complexity improvement.
- H2 fails the multi-instance consistency challenge.
- H3 is promoted to integration testing.
- H4 remains promising but is pruned for current delivery budget.
- A challenge branch tests H3 with cache outage and stampede traffic.
- A refinement adds request coalescing, bounded stale serving, and circuit breaking.
- The finalist is replicated from a clean worktree.

## Peer-review result

**Accept with conditions**

Conditions:

- rollout behind a feature flag;
- cache outage SLO and alert;
- stale-data metric;
- capacity test at 2× experimental load;
- recovery runbook;
- retain H1 database optimization because caching must not mask inefficient queries.

## Productionization

The accepted experiment becomes multiple change units rather than a direct merge.
