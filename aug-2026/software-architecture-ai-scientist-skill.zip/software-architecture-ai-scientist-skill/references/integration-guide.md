# Integration Guide

## Recommended tools

- repository and symbol search;
- Git history and worktrees;
- container or ephemeral environment management;
- build and test runners;
- benchmark harnesses;
- load generators;
- profilers and tracing;
- security scanners;
- fault-injection tools;
- cloud cost and telemetry queries;
- artifact storage;
- graph or structured research-memory storage.

## Host hooks

### Before research
- validate charter and safety policy;
- establish budget;
- snapshot baseline;
- initialize artifact directories.

### Before branch execution
- create isolated workspace;
- validate allowed paths, network, credentials, and resources;
- record environment fingerprint.

### After experiment
- capture exit state and artifacts;
- clean resources;
- update budget;
- prevent automatic merge;
- archive negative result.

### Before promotion
- validate invariant status;
- require baseline comparison;
- require uncertainty statement;
- check duplicate branch.

### Before completion
- run peer review;
- verify artifact references;
- disclose unexecuted checks;
- create productionization gap analysis.
