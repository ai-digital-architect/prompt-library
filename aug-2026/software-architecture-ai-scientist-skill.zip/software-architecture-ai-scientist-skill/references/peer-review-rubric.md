# Architecture Peer-Review Rubric

Score 1–10 and explain every score below 7.

## Significance

Is the problem worth architectural change?

## Baseline

Is the current state reproducible and fairly represented?

## Prior art

Were local history, known patterns, products, and standards considered?

## Hypothesis

Is it causal, falsifiable, and scoped?

## Method

Are experiments controlled, safe, and decision-relevant?

## Evidence

Are results complete, reproducible, and uncertainty-aware?

## Architecture

Are boundaries, data, contracts, dependencies, and failure semantics coherent?

## Security and resilience

Were threats, faults, recovery, and controls tested?

## Operability

Can the design be deployed, observed, supported, and rolled back?

## Migration

Is adoption incremental, compatible, and realistic?

## Simplicity

Is complexity proportionate to demonstrated benefit?

## Reporting

Are negative results, limitations, and artifacts visible?

## Recommendation thresholds

- **Accept:** no blocking concern; strong evidence.
- **Accept with conditions:** direction supported; named production gaps.
- **Major revision:** plausible, but decisive evidence/design work missing.
- **Reject:** mechanism falsified, unsafe, or unjustified.
- **Insufficient evidence:** conclusion cannot be supported within current experiment.
