# Experimental Validity for Architecture Research

## Internal validity

Could another change explain the result?

Control versions, configuration, datasets, warm-up, cache state, infrastructure, and concurrent load.

## External validity

Does the experiment represent actual production conditions?

Declare workload shape, scale, data distribution, dependencies, failure rates, and organizational
assumptions.

## Construct validity

Does the metric represent the desired outcome?

Examples:

- lines of code do not directly measure maintainability;
- test coverage does not directly measure correctness;
- average latency does not represent tail latency;
- number of services does not measure modularity;
- benchmark throughput does not prove recovery behavior.

## Conclusion validity

Is the observed difference stable enough to support the decision?

Use repetitions, variance, effect size, sensitivity, and explicit uncertainty.

## Reproducibility

Record:

- base commit;
- environment fingerprint;
- dependency locks;
- configuration;
- data/workload;
- commands;
- random seeds;
- raw results;
- analysis code;
- artifact hashes.

## Threats to validity section

Every report must disclose:

- uncontrolled variables;
- missing environments;
- shallow simulation;
- test-data limitations;
- cost assumptions;
- unavailable production evidence;
- subjective scoring.
