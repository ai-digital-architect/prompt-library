# Architecture Hypothesis Guide

## Formula

```text
Under [declared workload and constraints],
changing [independent architecture variable]
because [causal mechanism]
will change [measured outcomes]
from [baseline]
to [threshold],
while preserving [invariants].
```

## Required properties

- repository-specific;
- causal;
- falsifiable;
- measurable;
- bounded;
- safe to test;
- accompanied by a minimal falsifier;
- explicit about trade-offs.

## Hypothesis families

- component boundaries;
- integration and messaging;
- consistency and transactions;
- caching and state;
- concurrency and scheduling;
- deployment and scaling;
- fault tolerance and recovery;
- security controls;
- build and developer workflow;
- migration sequencing;
- observability and detection;
- cost and capacity.

## Anti-patterns

- “Use industry best practices.”
- “Microservices are more scalable.”
- “This framework is faster.”
- “The new design will be enterprise-ready.”
- testing several major variables without isolation;
- choosing a metric after seeing the result;
- ignoring operational complexity;
- equating novelty with value.
