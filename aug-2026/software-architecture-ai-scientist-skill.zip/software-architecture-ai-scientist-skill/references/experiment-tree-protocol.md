# Progressive Agentic Experiment Tree Protocol

## Search state

```yaml
tree_state:
  root:
  active_frontier:
  promoted_nodes:
  pruned_nodes:
  failed_nodes:
  archived_nodes:
  consumed_budget:
  remaining_budget:
  best_current_node:
  uncertainty:
```

## Expansion policy

Expand a node when:

- multiple mechanisms plausibly explain the outcome;
- a successful result may be fragile;
- a design dimension remains uncertain;
- reviewer feedback proposes a material alternative.

## Refinement policy

Refine when:

- the mechanism is supported but thresholds are not met;
- an implementation flaw obscured the result;
- operations or security need strengthening;
- a simpler variant may preserve most of the benefit.

## Challenge policy

Create a challenge branch to:

- beat the finalist with a simpler design;
- falsify the causal explanation;
- test a hostile workload;
- test failure and recovery;
- expose metric gaming;
- remove a suspected unnecessary component.

## Replication policy

Replicate finalists with:

- clean workspace;
- repeated runs;
- alternative representative workload;
- independent runner when possible.

## Pruning policy

Never prune solely because an implementation failed. Diagnose failure class first.

## Checkpoint

Every promoted node must have:

- committed or archived implementation;
- exact experiment definition;
- full result;
- comparison to baseline;
- invariant status;
- cost;
- uncertainty;
- rationale for promotion.
