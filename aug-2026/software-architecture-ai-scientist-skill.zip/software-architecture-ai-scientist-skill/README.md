# Software Architecture and Engineering AI Scientist

A repository-aware skill that transforms architecture work into hypothesis-driven, experimental
engineering.

The package primarily follows **AI Scientist-v2**:

- progressive agentic tree search;
- a dedicated experiment manager;
- no requirement for a predefined human-authored code template;
- iterative hypothesis, implementation, experiment, analysis, and review;
- visual evidence review;
- reproducible artifacts and negative-result memory.

It also preserves useful **AI Scientist v1** mechanics:

- explicit idea generation;
- novelty/prior-art review;
- end-to-end experimental execution;
- structured report generation;
- automated peer review and revision.

## Package

```text
software-architecture-ai-scientist-skill/
├── SKILL.md
├── README.md
├── references/
│   ├── architecture-hypothesis-guide.md
│   ├── experiment-tree-protocol.md
│   ├── experimental-validity.md
│   ├── peer-review-rubric.md
│   └── integration-guide.md
├── templates/
│   ├── research-charter.md
│   ├── hypothesis.md
│   ├── experiment-node.md
│   ├── experiment-and-result.md
│   ├── architecture-research-report.md
│   └── peer-review.md
├── examples/
│   └── example-cache-architecture-study.md
└── evals/
    └── eval-cases.md
```

## Recommended placement

```text
.ai/
└── skills/
    └── software-architecture-ai-scientist/
```

Vendor-specific wrappers can reference this canonical package from `.claude`, `.github`, `.codex`,
`.cursor`, or another agent harness.

## Difference from Architecture Co-STORM

| Co-STORM package | AI Scientist package |
|---|---|
| Collaborative discourse | Autonomous experimental discovery |
| Dynamic knowledge map | Progressive experiment tree |
| Human and agent perspectives | Hypotheses and competing branches |
| Moderator chooses speakers | Experiment manager allocates budget |
| Agreement and dissent | Evidence, fitness, pruning, and promotion |
| Architecture deliberation | Architecture experimentation |
| Human workshop | Reproducible engineering laboratory |

They can be composed: Co-STORM identifies the most consequential hypotheses, and AI Scientist tests
them.
