# Evaluation Cases

Use these cases to evaluate whether the skill changes agent behavior, not merely report formatting.

## E1 — Premature technology choice

**Prompt:** “Move our order workflow to Kafka.”

**Pass conditions:**
- reframes the objective;
- investigates current failure and consistency needs;
- compares evolutionary and event-driven options;
- does not assume Kafka is required;
- defines event contracts, idempotency, delivery semantics and verification if selected.

## E2 — Repository architecture review

**Prompt:** “Review this monorepo and tell me what is wrong.”

**Pass conditions:**
- performs topology-first reconnaissance;
- uses multiple perspectives;
- links findings to exact repository evidence;
- prioritizes issues by outcome and risk;
- avoids generic pattern advice.

## E3 — Production readiness

**Prompt:** “Make this service enterprise ready.”

**Pass conditions:**
- defines enterprise-ready outcomes and controls;
- covers security, resiliency, SLOs, deployment, rollback, support and evidence;
- creates change units and a verification matrix;
- clearly marks checks not executed.

## E4 — Modernization pressure

**Prompt:** “Rewrite the legacy application as microservices.”

**Pass conditions:**
- investigates drivers and seams;
- compares modular-monolith and selective extraction options;
- proposes characterization tests and incremental migration;
- addresses data ownership, distributed failure and operational cost.

## E5 — Contradictory evidence

**Prompt:** Documentation says calls are asynchronous; code shows synchronous HTTP.

**Pass conditions:**
- records the contradiction;
- prioritizes code/runtime evidence;
- checks scope and freshness;
- avoids silently selecting one narrative;
- proposes an experiment when unresolved.

## E6 — Security-critical feature

**Prompt:** “Add a plugin marketplace.”

**Pass conditions:**
- identifies trust boundaries, publisher identity, signing, scanning, sandboxing, permissions,
  provenance, approval, revocation and runtime monitoring;
- includes attacker and operator perspectives;
- maps controls to verification.

## Failure indicators

- solution appears before investigation;
- all perspectives reach identical conclusions;
- uncited repository claims;
- “best practice” used as rationale;
- missing alternatives;
- no rollout, rollback or verification;
- claims that tests passed without execution evidence.
