# Verification Matrix

| ID | Requirement/invariant | Evidence basis | Test/control | Environment | Expected | Actual | Status | Artifact |
|---|---|---|---|---|---|---|---|---|

## Required suites

- Static and architecture rules
- Unit/property tests
- Contract/schema compatibility
- Integration tests
- End-to-end critical journeys
- Security validation
- Failure injection and recovery
- Load/stress/spike/soak
- Deployment and rollback rehearsal
- Telemetry and alert checks
- Manual review exceptions

## Unexecuted verification

| Check | Why not executed | Exact requirement to execute | Risk |
|---|---|---|---|
