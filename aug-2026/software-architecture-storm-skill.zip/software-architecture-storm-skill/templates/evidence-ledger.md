# Evidence and Knowledge Ledgers

## Evidence register

| ID | Source/location | Type | Freshness | Trust T1–T4 | Finding | Supports/contradicts |
|---|---|---|---|---|---|---|

## Contradiction ledger

| ID | Claim A | Claim B | Evidence | Resolution/experiment | Status |
|---|---|---|---|---|---|

## Risk ledger

| ID | Risk | Trigger | Impact | Likelihood | Mitigation/control | Residual risk | Owner |
|---|---|---|---|---|---|---|---|

## Open decisions

| ID | Decision | Options | Evidence needed | Deadline | Owner | Status |
|---|---|---|---|---|---|---|
