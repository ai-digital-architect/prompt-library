# Engineering Mission Brief

## Objective

## Desired outcomes

## Problem statement

## In scope

## Out of scope

## Stakeholders

## Criticality and change type

## Constraints

## Non-goals

## Required deliverables

## Definition of done

## Assumption ledger

| ID | Assumption | Why needed | Validation method | Owner | Status |
|---|---|---|---|---|---|

## Known unknowns

| ID | Unknown | Decision affected | Investigation |
|---|---|---|---|
