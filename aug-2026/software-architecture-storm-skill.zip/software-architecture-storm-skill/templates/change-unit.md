# Change Unit

- **ID:**
- **Outcome:**
- **Risk:**
- **Owner:**
- **Dependencies:**
- **Evidence/ADR links:**

## Scope

## Files or modules

## Interfaces and schemas changed

## Implementation steps

## Tests

## Security controls

## Observability

## Migration and rollout

## Rollback and recovery

## Acceptance criteria

## Explicitly deferred work
