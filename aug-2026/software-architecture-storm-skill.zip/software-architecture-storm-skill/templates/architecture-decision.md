# Architecture Decision Record

- **ID:**
- **Title:**
- **Status:** proposed | accepted | superseded | rejected
- **Date:**
- **Owners:**
- **Related requirements:**
- **Evidence IDs:**

## Context and problem

## Decision drivers

## Options

### Option A

### Option B

### Option C

## Comparison

| Criterion | Weight | A | B | C | Notes |
|---|---:|---:|---:|---:|---|

## Decision

## Rationale

## Consequences

### Positive

### Negative

### Risks and mitigations

## Architecture invariants

## Verification

## Revisit triggers
