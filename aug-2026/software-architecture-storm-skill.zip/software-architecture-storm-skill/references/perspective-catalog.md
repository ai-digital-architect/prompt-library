# Perspective Catalog

Select only perspectives that materially change the investigation.

## Domain and value

- Product strategist — outcomes, adoption, economic value and non-goals.
- Domain architect — capabilities, bounded contexts, invariants and ubiquitous language.
- Workflow analyst — actors, journeys, exceptions and human decision points.
- Data product owner — ownership, quality, lineage, retention and discoverability.

## Structure

- Application architect — modules, cohesion, coupling and dependency direction.
- Integration architect — APIs, events, contracts, choreography and failure semantics.
- Data architect — models, consistency, transactions, lifecycle and migration.
- Platform architect — shared capabilities, paved roads and tenancy.
- Cloud architect — runtime topology, managed services, limits and regional design.
- Evolutionary architect — fitness functions, changeability and incremental modernization.

## Quality and risk

- Security architect — trust boundaries, assets, threats and controls.
- Privacy engineer — minimization, consent, access, retention and deletion.
- Resiliency engineer — fault domains, recovery, retries and graceful degradation.
- Performance engineer — workload model, latency, throughput, contention and capacity.
- Reliability engineer — correctness, SLOs, error budgets and failure detection.
- Compliance architect — obligations, evidence, segregation and control sustainability.

## Delivery and operation

- Developer-experience lead — build speed, local setup, cognitive load and tooling.
- Test architect — test pyramid, contracts, environments and determinism.
- Release engineer — CI/CD, provenance, promotion, rollback and feature flags.
- SRE — telemetry, alerting, runbooks, on-call and operational toil.
- FinOps architect — unit economics, capacity, utilization and cost controls.
- Support engineer — diagnosability, remediation and customer-impact workflows.

## Adversarial lenses

- Skeptical principal engineer — challenges novelty, complexity and hidden coupling.
- Red-team attacker — seeks exploitable paths and control bypasses.
- Incident commander — assumes dependencies and automation fail during peak impact.
- Downstream consumer — tests compatibility, clarity and migration burden.
- Auditor — asks whether claims can be proven repeatedly.
- Future maintainer — tests readability, ownership and long-term change cost.
