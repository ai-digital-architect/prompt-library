# Software Engineering and Architecture STORM Skill

A portable, repository-aware skill that adapts Stanford STORM's multi-perspective, retrieval-grounded
research workflow to software engineering and architecture.

## Contents

- `SKILL.md` — complete skill definition and operating workflow.
- `references/perspective-catalog.md` — perspective selection catalog.
- `templates/mission-brief.md` — mission and scope template.
- `templates/evidence-ledger.md` — evidence, assumptions and contradictions.
- `templates/architecture-decision.md` — option comparison and ADR template.
- `templates/change-unit.md` — executable implementation increment.
- `templates/verification-matrix.md` — proof and production-readiness matrix.
- `evals/eval-cases.md` — behavioral evaluation scenarios.

## Installation patterns

### Claude Code

Place the directory under a repository or user skill location supported by your Claude Code setup,
preserving `SKILL.md` as the skill entry point.

### GitHub Copilot

Use `SKILL.md` as the authoritative workflow and reference it from repository custom instructions,
prompt files or custom agents. Keep templates in the repository so generated decisions and plans are
versioned with the code.

### Codex or other coding agents

Add the directory to the agent's repository instructions/skills area and invoke it for architecture,
modernization, repository-analysis and production-readiness tasks.

## Recommended repository placement

```text
.ai/
└── skills/
    └── software-architecture-storm/
        ├── SKILL.md
        ├── references/
        ├── templates/
        └── evals/
```

Vendor-specific wrappers can point to this canonical skill to avoid duplicated behavior.
