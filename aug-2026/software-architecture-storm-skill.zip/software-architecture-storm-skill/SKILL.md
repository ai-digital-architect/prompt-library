---
name: software-architecture-storm
description: >
  Conducts rigorous, multi-perspective software engineering and architecture investigations
  using a STORM-inspired workflow: perspective discovery, evidence-grounded questioning,
  iterative expert conversations, architecture synthesis, implementation planning, and
  verification. Use for architecture reviews, modernization, feature design, platform design,
  repository analysis, security/resiliency assessments, technical-debt remediation, and
  production-readiness decisions.
version: 1.0.0
license: MIT
tags:
  - architecture
  - software-engineering
  - deep-research
  - repository-analysis
  - design-review
  - implementation-planning
  - verification
---

# Software Engineering and Architecture STORM

## Purpose

Transform a vague engineering objective into an evidence-grounded, decision-ready and executable
engineering outcome.

This skill adapts Stanford STORM's pre-writing pattern to software engineering:

| Stanford STORM | Engineering STORM |
|---|---|
| Topic | Engineering objective or problem |
| Perspectives | Architecture, security, product, operations and delivery lenses |
| Writer questions | Investigation questions and hypotheses |
| Topic expert | Repository, runtime, documentation, standards and human experts |
| Retrieved references | Source code, ADRs, APIs, telemetry, controls, tests and authoritative sources |
| Curated outline | Architecture decision structure and change map |
| Article generation | Architecture package, implementation plan and engineering artifacts |
| Article polishing | Cross-checking, risk resolution, verification and executive synthesis |

The skill does **not** jump directly from request to solution. It first builds a defensible model of
the problem, explores it through independent perspectives, records evidence, resolves contradictions,
then creates and verifies the proposed design.

---

## When to Invoke

Invoke this skill when the user asks to:

- design or review a software architecture;
- analyze one or more repositories;
- modernize, migrate, decompose or re-platform a system;
- design a feature whose impact spans components or teams;
- assess security, resiliency, operability, scalability or compliance;
- produce ADRs, RFCs, solution designs or implementation plans;
- investigate a recurring defect, incident or performance problem;
- evaluate technology or architecture alternatives;
- prepare a system for production or enterprise approval;
- convert research into an executable engineering plan.

Do not invoke the full workflow for a trivial code edit, isolated syntax question, or change that is
clearly local and low-risk. Use the **compact mode** for bounded changes.

---

## Operating Principles

1. **Evidence before assertion.** Distinguish observed facts, inferred conclusions, assumptions and recommendations.
2. **Repository truth outranks prose.** Code, configuration, tests and runtime evidence take priority over stale documentation.
3. **Multiple perspectives before convergence.** Do not let the first plausible design dominate.
4. **Questions must evolve.** Answers should generate more precise follow-up questions.
5. **Trace every material decision.** Link decisions to requirements, evidence, constraints and verification.
6. **Design for failure and operation.** Include deployment, rollback, observability, security and supportability.
7. **Architecture must become executable.** Produce concrete change units, interfaces, tests and acceptance criteria.
8. **Verification is part of design.** A recommendation without a feasible verification method is incomplete.
9. **Prefer the smallest coherent change.** Avoid speculative platforms, abstractions and rewrites.
10. **Expose uncertainty.** Use confidence levels and explicitly list unresolved questions.

---

## Inputs

Accept whatever is available and proceed with best effort:

- objective, problem statement or desired outcome;
- repository or monorepo;
- architecture diagrams, ADRs, standards or control documents;
- incident data, logs, traces, metrics or support tickets;
- constraints such as languages, cloud, deadlines, regulation or budget;
- target audience and expected deliverables.

When inputs are incomplete, create a short assumption ledger instead of blocking progress.

---

## Modes

### Compact Mode

Use for a bounded feature, component review or architecture question.

Minimum phases:

1. Frame
2. Select 4–6 perspectives
3. Investigate
4. Synthesize
5. Plan
6. Verify

### Full Mode

Use for system-wide, high-risk, enterprise, regulated or modernization work.

Run all phases and maintain the complete evidence and decision ledgers.

### Collaborative Mode

Use when the user is actively steering the investigation.

After each major synthesis cycle:

- show the current architecture map;
- identify the highest-impact uncertainty;
- accept user steering;
- update perspectives and investigation priorities;
- preserve superseded decisions and why they changed.

---

# Workflow

## Phase 0 — Frame the Mission

Create an **Engineering Mission Brief**:

```yaml
mission:
  objective:
  desired_outcomes:
  problem_statement:
  in_scope:
  out_of_scope:
  stakeholders:
  business_criticality: low|medium|high|mission-critical
  change_type: feature|modernization|migration|remediation|review|incident|platform
  constraints:
  non_goals:
  required_deliverables:
  decision_deadline:
```

Also create:

- an assumption ledger;
- a known-unknowns list;
- an initial risk classification;
- a definition of done.

Rewrite solution-shaped requests into outcome language. For example, replace “move to Kafka” with
“provide durable, replayable and independently consumable domain-event distribution.”

### Exit criteria

- The objective is testable.
- Scope and non-goals are visible.
- Constraints are separated from preferences.
- No technology choice is treated as a requirement without evidence.

---

## Phase 1 — Build the Evidence Topology

Discover all relevant evidence sources.

### Internal evidence

- source files and module boundaries;
- build manifests and dependency locks;
- API and event schemas;
- database schemas and migrations;
- infrastructure as code;
- CI/CD definitions;
- deployment manifests;
- tests, fixtures and test reports;
- ADRs, RFCs, diagrams and runbooks;
- security policies and architecture standards;
- telemetry, SLOs, incidents and postmortems;
- issue trackers and change history.

### External evidence

Use authoritative primary sources for:

- language and framework behavior;
- vendor and cloud service semantics;
- standards and protocols;
- security advisories;
- regulatory or control requirements;
- relevant research.

Create an **Evidence Register**:

| ID | Source | Type | Freshness | Trust | Scope | Key finding |
|---|---|---|---|---|---|---|

Trust levels:

- **T1:** directly observed code/runtime evidence or authoritative standard;
- **T2:** current official documentation or validated internal documentation;
- **T3:** informed secondary source;
- **T4:** unverified statement, memory or assumption.

### Repository reconnaissance

Map:

- languages and frameworks;
- build and package topology;
- deployable units;
- public and internal interfaces;
- persistent stores;
- inbound and outbound dependencies;
- execution paths;
- ownership boundaries;
- test distribution;
- security-sensitive areas;
- operational control points.

Do not read every file sequentially. Start broad, identify architectural seams, then deepen selectively.

### Exit criteria

- Important claims can be tied to evidence.
- Stale or conflicting sources are marked.
- The investigation has a navigable system map.

---

## Phase 2 — Discover Engineering Perspectives

Select perspectives dynamically. Use at least one perspective from each required category.

### Required categories

**Value and domain**
- product outcome;
- business capability;
- domain model and bounded context;
- user experience and workflow.

**Structure and design**
- software architecture;
- data architecture;
- API/event integration;
- dependency and modularity;
- evolutionary architecture.

**Quality and risk**
- security and privacy;
- resiliency and disaster recovery;
- performance and scalability;
- reliability and correctness;
- compliance and auditability.

**Delivery and operations**
- developer experience;
- testability;
- CI/CD and release engineering;
- observability and SRE;
- cost and capacity;
- support and operability.

### Optional adversarial perspectives

- skeptical principal engineer;
- red-team security architect;
- production incident commander;
- migration owner;
- downstream consumer;
- regulator or auditor;
- cost controller;
- accessibility specialist;
- data governance lead.

Create a **Perspective Charter** for each selected lens:

```yaml
perspective:
  name:
  mandate:
  success_criteria:
  primary_concerns:
  evidence_needed:
  anti_goals:
  likely_blind_spots:
```

Perspectives must be meaningfully different, not role-name variations that ask the same questions.

### Exit criteria

- Coverage spans value, structure, quality and operations.
- At least one perspective challenges the likely preferred solution.
- Each perspective has distinct evidence needs.

---

## Phase 3 — Generate the Investigation Graph

Each perspective generates questions, hypotheses and failure probes.

### Question classes

1. **Descriptive:** What exists?
2. **Causal:** Why does it behave this way?
3. **Constraint:** What cannot change?
4. **Counterfactual:** What happens under an alternative?
5. **Failure:** How does this break?
6. **Evolution:** How will it change over time?
7. **Verification:** How will we know it works?
8. **Trade-off:** What is gained, lost or deferred?

Use a graph, not a flat questionnaire:

```yaml
question:
  id:
  perspective:
  text:
  parent_question:
  hypothesis:
  evidence_required:
  priority: critical|high|medium|low
  status: open|answered|partially-answered|contradicted
  answer_summary:
  evidence_ids:
  follow_up_questions:
  confidence: high|medium|low
```

### Prioritization

Use:

`priority = decision_impact × uncertainty × reversibility_cost × risk_exposure`

Investigate high-impact, high-uncertainty and hard-to-reverse decisions first.

### Exit criteria

- Every major design decision has precursor questions.
- Questions identify evidence needed.
- The graph contains failure and verification questions, not only descriptive ones.

---

## Phase 4 — Run Grounded Expert Conversations

Simulate iterative conversations between each **Perspective Investigator** and an **Evidence Expert**.

### Perspective Investigator behavior

- asks one precise question at a time;
- carries the perspective charter;
- updates its mental model after each answer;
- asks follow-ups triggered by evidence;
- challenges unsupported assumptions;
- stops when marginal information gain is low.

### Evidence Expert behavior

- retrieves and cites relevant evidence;
- separates direct observation from inference;
- reports contradictions;
- refuses to invent missing repository or runtime facts;
- identifies evidence gaps and recommends a validation method.

### Conversation turn format

```markdown
#### Q-SEC-04
**Question:** Can an untrusted caller influence the command executed by the worker?

**Answer:** ...
**Evidence:** E-17, E-28
**Interpretation:** ...
**Contradictions:** ...
**Confidence:** Medium
**Next questions:** Q-SEC-05, Q-OPS-09
```

### Stopping conditions

Stop a perspective conversation when:

- critical questions are answered;
- remaining uncertainty is explicitly bounded;
- new turns repeat known findings;
- evidence is unavailable and a validation experiment is defined;
- the decision can be made with stated confidence.

Never stop merely because an initial plausible answer was found.

### Exit criteria

- Material findings are evidence-linked.
- Follow-up questions demonstrate iterative learning.
- Contradictions and gaps are retained.

---

## Phase 5 — Curate the Engineering Knowledge Base

Normalize findings into a shared model.

### Required ledgers

1. **Evidence ledger**
2. **Assumption ledger**
3. **Decision ledger**
4. **Risk ledger**
5. **Requirement and quality-attribute ledger**
6. **Contradiction ledger**
7. **Open-question ledger**
8. **Verification ledger**

### Architecture knowledge graph

Represent important relationships:

```text
Outcome -> motivates -> Requirement
Requirement -> constrained_by -> Constraint
Requirement -> realized_by -> Capability
Capability -> implemented_by -> Component
Component -> exposes -> Interface
Component -> reads/writes -> Data
Component -> depends_on -> Dependency
Component -> deployed_as -> RuntimeUnit
Risk -> threatens -> Asset/Outcome
Control -> mitigates -> Risk
Decision -> selects/rejects -> Option
Decision -> supported_by -> Evidence
Test -> verifies -> Requirement/Decision
```

### Contradiction handling

For each contradiction:

- identify conflicting claims;
- rank source trust and freshness;
- inspect scope differences;
- determine whether both can be true;
- resolve through code/runtime evidence or experiment;
- leave unresolved when evidence is insufficient.

### Exit criteria

- Duplicate findings are merged without losing provenance.
- Contradictions are resolved or visible.
- Decisions, risks and tests are connected to evidence.

---

## Phase 6 — Generate the Architecture Outline

Before writing a solution, create a hierarchical outline based on the curated knowledge.

Required structure:

1. Executive decision
2. Mission and outcomes
3. Current-state architecture
4. Key findings by perspective
5. Quality attributes and constraints
6. Options considered
7. Recommended target architecture
8. Detailed component, data and integration design
9. Security and threat model
10. Resiliency, performance and operability
11. Delivery and migration plan
12. Verification strategy
13. Risks, assumptions and unresolved decisions
14. ADRs and appendices

Score the outline:

| Dimension | Question |
|---|---|
| Coverage | Does every critical perspective appear? |
| Depth | Are hard questions represented below the headline level? |
| Organization | Does each section have one coherent purpose? |
| Traceability | Can recommendations be traced to findings? |
| Actionability | Does the outline lead toward buildable changes? |
| Balance | Are alternatives and dissent represented? |

Revise the outline before drafting when any score is weak.

### Exit criteria

- The structure reflects discovered evidence rather than a generic template.
- Options and trade-offs precede recommendation.
- Verification is a first-class section.

---

## Phase 7 — Synthesize Architecture Options

Generate at least:

- **Option A — Minimal/evolutionary change**
- **Option B — Strategic target**
- **Option C — Meaningfully different alternative**
- **Option D — Do nothing / defer**, when useful

For each option document:

```yaml
option:
  summary:
  architecture:
  outcomes_enabled:
  constraints_satisfied:
  quality_attribute_impacts:
  migration_complexity:
  operational_complexity:
  security_implications:
  cost_profile:
  reversibility:
  key_risks:
  evidence_support:
  verification_approach:
```

Use a weighted decision record, but do not hide judgment behind arithmetic. Explain weight choices and
sensitivity.

### Recommendation rule

Recommend the option with the best **risk-adjusted outcome**, not the most technologically ambitious
design.

### Exit criteria

- Alternatives are genuinely distinct.
- Rejected options have evidence-based rationale.
- The recommendation includes conditions under which it should be revisited.

---

## Phase 8 — Produce the Target Architecture

The target design must cover:

### Functional architecture

- actors and use cases;
- business capabilities;
- domain boundaries;
- critical workflows;
- invariants and policy decisions.

### Application architecture

- components and responsibilities;
- ports, adapters and interfaces;
- dependency rules;
- synchronous and asynchronous interactions;
- state ownership;
- extension points.

### Data architecture

- system of record;
- schemas and ownership;
- consistency model;
- lifecycle, retention and deletion;
- lineage and privacy;
- migration and backward compatibility.

### Infrastructure and deployment

- runtime topology;
- environments and isolation;
- networking and trust zones;
- scaling and capacity;
- deployment and rollback;
- recovery topology.

### Cross-cutting architecture

- identity, authentication and authorization;
- secrets and key management;
- logging, metrics and tracing;
- error model and retries;
- idempotency and concurrency;
- configuration and feature flags;
- policy enforcement;
- audit evidence.

### Architecture invariants

Express enforceable rules such as:

```text
Domain modules MUST NOT import infrastructure adapters.
Every externally retried command MUST be idempotent.
PII MUST NOT appear in application logs.
Schema changes MUST remain backward compatible for the declared support window.
Each critical user journey MUST have an SLO and an observable success signal.
```

For each invariant define an automated or procedural control.

### Exit criteria

- Component responsibilities do not overlap ambiguously.
- Data and failure semantics are explicit.
- Cross-cutting concerns are placed in the architecture, not deferred.
- Invariants are verifiable.

---

## Phase 9 — Convert Architecture into an Executable Change Plan

Create vertical, testable change increments.

Each **Change Unit** includes:

```yaml
change_unit:
  id:
  outcome:
  scope:
  files_or_modules:
  interfaces_changed:
  dependencies:
  implementation_steps:
  tests:
  observability:
  security_controls:
  migration_or_rollout:
  rollback:
  acceptance_criteria:
  evidence_and_decisions:
  estimated_risk:
```

### Sequencing rules

1. Establish characterization tests before risky refactoring.
2. Create seams before replacing implementations.
3. Introduce backward-compatible interfaces before migrating consumers.
4. Deploy observability before changing critical behavior.
5. Separate reversible and irreversible changes.
6. Use expand–migrate–contract for schemas and APIs.
7. Include rollback and data recovery for every production change.
8. Keep increments independently reviewable and demonstrable.

### Worktree/agent parallelization

Parallelize only change units with explicit boundaries.

For each parallel branch define:

- owned paths;
- allowed interfaces;
- dependency contract;
- expected artifacts;
- merge prerequisites;
- conflict owner.

Do not let multiple agents silently edit the same architectural seam.

### Exit criteria

- Every recommendation maps to change units.
- Each change unit has tests and rollback.
- Dependencies form a valid execution order.

---

## Phase 10 — Implement with Continuous Re-grounding

When implementation is requested:

1. inspect relevant files immediately before editing;
2. state the intended invariant and acceptance criteria;
3. make the smallest coherent change;
4. run focused checks;
5. inspect failures rather than weakening tests;
6. update the evidence and decision ledgers when reality differs;
7. keep generated code consistent with local conventions;
8. avoid unrelated cleanup;
9. preserve backward compatibility unless explicitly approved;
10. record deferred work rather than hiding it.

### Escalation triggers

Pause implementation synthesis and revisit architecture when:

- a core assumption is disproved;
- an interface cannot satisfy required semantics;
- security boundaries differ from the model;
- migration requires destructive or irreversible steps;
- observed runtime behavior contradicts design evidence;
- the change expands beyond the agreed blast radius.

---

## Phase 11 — Verification STORM

Run a second, adversarial mini-STORM focused on proving or disproving the design.

### Verification perspectives

- correctness examiner;
- security attacker;
- failure-injection engineer;
- performance engineer;
- operability reviewer;
- maintainability reviewer;
- compliance/control reviewer;
- downstream consumer.

### Verification layers

1. Static analysis and dependency rules
2. Unit and property tests
3. Contract and schema compatibility tests
4. Integration tests
5. End-to-end critical journeys
6. Security tests and threat-control validation
7. Resiliency and failure-injection tests
8. Load, stress, spike and soak tests
9. Deployment, rollback and recovery rehearsal
10. Observability and alert validation
11. Manual architecture review for non-automatable concerns

### Verification matrix

| Requirement/Invariant | Evidence | Test/Control | Expected result | Actual result | Status |
|---|---|---|---|---|---|

Never claim completion when a required verification was not run. Mark it **not executed**, explain why,
and provide the exact command, environment or evidence needed.

### Exit criteria

- Critical requirements have verification coverage.
- Security and failure behavior were tested, not assumed.
- Unexecuted checks are explicit.
- Findings feed back into architecture and plan.

---

## Phase 12 — Polish and Package the Outcome

Generate the deliverables appropriate to the audience.

### Executive package

- decision statement;
- business and technology outcomes;
- major risks and mitigations;
- investment and sequencing;
- decisions required.

### Architecture package

- architecture document;
- context/container/component/data/deployment views;
- ADR set;
- threat model;
- NFR and SLO catalog;
- migration architecture;
- standards exceptions.

### Engineering package

- repository findings;
- change-unit backlog;
- interface/schema specifications;
- test and verification plan;
- CI/CD and operational changes;
- runbooks and rollback.

### Final quality pass

Check for:

- unsupported claims;
- citation/evidence gaps;
- internal contradictions;
- generic recommendations;
- missing failure semantics;
- missing ownership;
- missing rollout or rollback;
- unverified claims of completion;
- duplicated content;
- architectural red herrings.

---

# Agent Roles

These are logical roles. They may be separate agents or sequential modes in one agent.

## 1. Mission Framer

Converts the request into outcomes, scope, constraints and definition of done.

## 2. Repository Cartographer

Builds the code, dependency, interface, data and deployment map.

## 3. Perspective Miner

Chooses diverse engineering perspectives based on context and risk.

## 4. Question Strategist

Creates and prioritizes the investigation graph.

## 5. Evidence Expert

Retrieves, cites and qualifies internal and external evidence.

## 6. Perspective Investigators

Run iterative, perspective-specific conversations.

## 7. Knowledge Curator

Normalizes findings, resolves contradictions and maintains ledgers.

## 8. Architecture Synthesizer

Creates alternatives, target architecture, invariants and ADRs.

## 9. Delivery Planner

Converts design into sequenced, testable change units.

## 10. Verification Council

Adversarially evaluates correctness, security, resiliency and operability.

## 11. Editor/Packager

Produces coherent, audience-specific final artifacts.

---

# Required Output Contract

At minimum, return:

```markdown
# Engineering STORM Result

## 1. Executive Decision
## 2. Mission and Scope
## 3. Evidence and Current-State Findings
## 4. Perspectives Investigated
## 5. Critical Questions and Answers
## 6. Architecture Options
## 7. Recommendation
## 8. Target Architecture
## 9. Security, Resiliency and Operability
## 10. Executable Change Plan
## 11. Verification Matrix
## 12. Risks, Assumptions and Open Decisions
## 13. ADRs
## 14. Evidence Register
```

For smaller tasks, compress sections but preserve evidence, alternatives, plan and verification.

---

# Guardrails

- Do not fabricate repository structure, test execution, telemetry or tool results.
- Do not present assumptions as facts.
- Do not recommend a rewrite without comparing evolutionary alternatives.
- Do not introduce a distributed system where a modular local design satisfies the outcomes.
- Do not use “best practice” as the sole rationale.
- Do not suppress dissenting perspectives.
- Do not expose secrets, credentials or sensitive data found during investigation.
- Do not weaken security or tests merely to make implementation pass.
- Do not conflate code generation with successful delivery.
- Do not mark a control complete without evidence.
- Do not rely on a single source for high-impact external claims.
- Do not allow the report structure to become more important than the engineering decision.

---

# Quality Gates

## Gate A — Mission

- Outcome is measurable.
- Scope and constraints are explicit.
- Assumptions are visible.

## Gate B — Research

- Multiple distinct perspectives were used.
- High-impact questions have evidence.
- Contradictions are tracked.

## Gate C — Architecture

- At least two viable options were considered.
- Recommendation traces to outcomes and evidence.
- Failure, data and security semantics are explicit.

## Gate D — Execution

- Change units are vertical and testable.
- Migration and rollback are defined.
- Ownership and dependencies are clear.

## Gate E — Verification

- Critical requirements map to tests or controls.
- Unexecuted verification is disclosed.
- Residual risk is accepted explicitly or remains open.

A gate failure must result in revision or an explicit exception.

---

# Compact Invocation Prompt

Use this prompt when a host supports skill invocation text:

```text
Run Software Engineering and Architecture STORM on the following objective.

First frame the outcome and scope. Discover diverse engineering perspectives. Build an evidence-backed
investigation graph and run iterative question-answer cycles grounded in repository, runtime,
documentation and authoritative external evidence. Curate findings, contradictions, risks and
assumptions. Generate meaningful architecture alternatives, recommend the best risk-adjusted option,
define the target architecture and invariants, convert it into sequenced change units, and run an
adversarial verification pass.

Never invent repository facts or claim tests were run when they were not. Distinguish observation,
inference, assumption and recommendation. Optimize for the smallest coherent architecture that meets
the outcomes.

Objective:
{{OBJECTIVE}}

Available context:
{{CONTEXT}}

Constraints:
{{CONSTRAINTS}}

Requested deliverables:
{{DELIVERABLES}}
```

---

# Provenance

This skill is an independent software-engineering adaptation inspired by Stanford's STORM methodology.
STORM separates pre-writing research from writing, discovers diverse perspectives, simulates
retrieval-grounded conversations with follow-up questions, curates an outline, and then produces a
citation-backed article. The engineering adaptation preserves those mechanics while replacing article
production with architecture decisions, executable change plans and verification.

Primary references:

- Stanford OVAL, `stanford-oval/storm`, official open-source repository.
- Yijia Shao et al., “Assisting in Writing Wikipedia-like Articles From Scratch with Large Language
  Models,” NAACL 2024, arXiv:2402.14207.
- Stanford STORM research project website.
