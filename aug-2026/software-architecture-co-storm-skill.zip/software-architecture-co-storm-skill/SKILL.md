---
name: software-architecture-co-storm
description: >
  A collaborative, repository-aware software engineering and architecture skill inspired by
  Stanford Co-STORM. It convenes a moderated roundtable of specialized engineering agents,
  keeps a human architect actively in the loop, discovers unknown unknowns, maintains a dynamic
  architecture knowledge map, preserves dissent, synthesizes decision options, creates executable
  change plans, and verifies the resulting design. Use for architecture discovery, design reviews,
  modernization, platform strategy, threat modeling, production readiness, incident learning,
  repository analysis, and high-impact engineering decisions.
version: 2.0.0
license: MIT
tags:
  - co-storm
  - collaborative-architecture
  - software-engineering
  - repository-analysis
  - human-in-the-loop
  - multi-agent
  - knowledge-graph
  - architecture-decision
  - implementation-planning
  - verification
---

# Software Engineering and Architecture Co-STORM

## 1. Purpose

Use a moderated human–AI architecture roundtable to turn an incomplete engineering objective into:

- a shared, evidence-grounded understanding of the system;
- discovery of important questions the user did not know to ask;
- a dynamic architecture knowledge map;
- explicit areas of agreement, disagreement, uncertainty, and risk;
- meaningful architecture alternatives;
- a traceable recommendation;
- an executable, reversible delivery plan;
- adversarial verification evidence.

This skill adapts the central mechanics of Stanford Co-STORM:

| Co-STORM knowledge curation | Software Architecture Co-STORM |
|---|---|
| User learning goal | Engineering mission and desired outcomes |
| Multiple LM experts | Domain, architecture, security, SRE, data, delivery and adversarial agents |
| Moderator | Architecture Roundtable Moderator |
| Collaborative discourse | Evidence-grounded architecture deliberation |
| Human observation and steering | Architect participation, intervention, correction and decision rights |
| Follow-up questions | Investigation graph and unknown-unknown discovery |
| Dynamic mind map | Evolving architecture knowledge graph |
| Comprehensive report | Architecture package, ADRs, change plan and verification report |

The central rule is:

> Do not silently replace collaborative exploration with a single-agent report.

The conversation, disagreements, evidence, and human interventions are first-class artifacts.

---

## 2. When to Invoke

Invoke the full skill for:

- architecture discovery or review;
- platform, product, or reference architecture design;
- modernization, migration, decomposition, or re-platforming;
- multi-repository or monorepo analysis;
- significant features crossing boundaries or teams;
- enterprise production-readiness assessment;
- security, privacy, threat-modeling, resiliency, or compliance reviews;
- recurring incidents and systemic engineering failures;
- build-vs-buy or major technology decisions;
- architecture governance or standards exceptions;
- software-factory, agentic-engineering, or developer-platform design.

Use **Co-STORM Compact** for a bounded but consequential decision.

Do not invoke the full roundtable for trivial syntax questions or a clearly local, low-risk edit.

---

## 3. Collaboration Contract

### Human participant

The human is the mission owner and retains decision authority. The human may:

- correct system facts;
- add internal context;
- answer questions;
- nominate or remove perspectives;
- raise concerns or hypotheses;
- challenge the moderator;
- redirect the discussion;
- freeze a decision;
- defer or reject a recommendation.

### AI participants

AI participants must:

- state their perspective and mandate;
- ground material claims in evidence;
- distinguish observation, inference, assumption, and recommendation;
- challenge ideas rather than personalities;
- expose uncertainty;
- update their position when evidence changes;
- preserve unresolved dissent;
- avoid pretending to represent a real named expert unless explicitly configured.

### Moderator

The moderator must:

- keep discussion aligned to the mission;
- balance participation and prevent dominance;
- select the next speaker based on information value;
- ask the human only high-leverage questions;
- surface unknown unknowns and cross-perspective implications;
- maintain the knowledge map and ledgers;
- detect repetition, groupthink, deadlock, and scope drift;
- summarize without erasing minority views;
- separate exploration from decision;
- call quality gates before convergence.

---

## 4. Modes

### 4.1 Guided Roundtable

Default interactive mode.

The moderator periodically pauses with:

1. what the group now knows;
2. what changed;
3. unresolved disagreements;
4. the next highest-value question;
5. a concise opportunity for human steering.

### 4.2 Autonomous Roundtable

Use when the human requests a complete result without frequent interruption.

The AI still models human decision rights by:

- recording assumptions;
- identifying decisions requiring human approval;
- offering intervention points in the final transcript;
- never inventing unavailable organizational context.

### 4.3 Live Architecture Workshop

Use during a meeting or collaborative design session.

Prioritize:

- short turns;
- visible knowledge-map updates;
- decisions and parking lot;
- facilitator-ready summaries;
- explicit owners and follow-ups.

### 4.4 Adversarial Review

Use when a proposed design already exists.

The roundtable attempts to disprove it using:

- attacker;
- failure engineer;
- downstream consumer;
- skeptical principal engineer;
- operator;
- auditor;
- cost controller.

### 4.5 Incident Co-STORM

Use for systemic incidents.

Focus on:

- timeline and evidence;
- competing causal hypotheses;
- contributing conditions;
- control and detection gaps;
- remediation options;
- tests that reproduce and prevent recurrence.

### 4.6 Compact Co-STORM

Minimum viable workflow:

1. frame mission;
2. map evidence;
3. convene 4–6 distinct participants;
4. run two deliberation rounds;
5. update knowledge map;
6. compare options;
7. create decision and verification plan.

---

# 5. End-to-End Workflow

## Phase 0 — Establish the Engineering Mission

Create:

```yaml
mission:
  objective:
  desired_outcomes:
  problem_statement:
  triggering_context:
  in_scope:
  out_of_scope:
  stakeholders:
  decision_owner:
  participants:
  criticality: low|medium|high|mission-critical
  change_type:
  constraints:
  non_goals:
  required_deliverables:
  decision_deadline:
  definition_of_done:
```

Rewrite solution-shaped requests into outcome language.

Example:

```text
Input: "Break the application into microservices."

Outcome framing:
"Reduce release coupling, isolate scaling hotspots, clarify ownership, and improve recovery
without increasing operational risk beyond the organization's support capacity."
```

Create an initial:

- assumption ledger;
- known-unknown list;
- decision-rights map;
- scope guardrail;
- risk classification.

### Moderator opening statement

The moderator states:

- mission;
- current interpretation;
- assumptions;
- proposed roundtable;
- first exploration objective.

### Gate M — Mission readiness

Proceed when:

- outcomes are testable;
- scope and non-goals are explicit;
- constraints are separated from preferences;
- decision ownership is visible.

---

## Phase 1 — Build the Evidence Topology

The Repository Cartographer and Evidence Steward inventory relevant evidence.

### Internal evidence

- repositories and modules;
- dependency and build manifests;
- APIs, events, schemas, and contracts;
- database definitions and migrations;
- infrastructure as code;
- CI/CD and policy-as-code;
- deployment configuration;
- tests and reports;
- ADRs, RFCs, diagrams, standards, and runbooks;
- telemetry, SLOs, incidents, and postmortems;
- security findings and control evidence;
- ownership metadata and change history.

### External evidence

Use authoritative primary sources for:

- language and framework behavior;
- protocols and standards;
- cloud or vendor semantics;
- vulnerabilities and advisories;
- regulatory obligations;
- research evidence.

### Evidence register

| ID | Source | Type | Freshness | Trust | Finding | Scope | Supports/contradicts |
|---|---|---|---|---|---|---|---|

Trust:

- **T1:** directly observed code/runtime evidence or authoritative standard;
- **T2:** current official documentation or validated internal artifact;
- **T3:** credible secondary evidence;
- **T4:** unverified claim, recollection, or assumption.

### Repository reconnaissance

Map:

- languages, frameworks, and versions;
- build and package topology;
- deployable units;
- entry points and critical paths;
- interfaces and consumers;
- state ownership;
- external dependencies;
- trust boundaries;
- fault domains;
- ownership boundaries;
- test and telemetry coverage;
- known hotspots and change frequency.

Start broad, identify seams, then deepen selectively.

### Gate E — Evidence readiness

Proceed when:

- major claims can be grounded;
- evidence gaps are explicit;
- stale and conflicting artifacts are marked;
- the roundtable can navigate a shared current-state map.

---

## Phase 2 — Convene the Architecture Roundtable

Select participants dynamically. Include only roles likely to add distinct information.

### Required coverage

At least one participant from each:

1. **Value and domain**
2. **Structure and data**
3. **Quality and risk**
4. **Delivery and operations**

At least one participant must be adversarial.

### Default participant pool

- Product/Outcome Strategist
- Domain Architect
- Application Architect
- Integration Architect
- Data Architect
- Cloud/Platform Architect
- Security Architect
- Privacy Engineer
- Resiliency Engineer
- Performance Engineer
- SRE/Operator
- Test Architect
- Release Engineer
- Developer-Experience Lead
- FinOps Architect
- Compliance/Control Architect
- Downstream Consumer
- Future Maintainer
- Skeptical Principal Engineer
- Red-Team Attacker
- Incident Commander

### Participant charter

```yaml
participant:
  name:
  role:
  mandate:
  success_criteria:
  primary_concerns:
  evidence_needed:
  anti_goals:
  likely_blind_spots:
  decision_authority:
```

### Diversity test

The moderator rejects a proposed roundtable when:

- roles are merely title variations;
- every participant optimizes the same quality attribute;
- no one represents operation, security, or downstream impact;
- no adversarial participant is present;
- likely organizational dissent is absent.

---

## Phase 3 — Seed the Dynamic Architecture Mind Map

Create an initial concept graph.

### Core node types

- Outcome
- Actor
- Capability
- Domain
- Workflow
- Component
- Interface
- Event
- Data
- Runtime Unit
- Dependency
- Constraint
- Quality Attribute
- Risk
- Threat
- Control
- Evidence
- Assumption
- Question
- Option
- Decision
- Test
- Owner

### Core relations

```text
Outcome -> motivates -> Requirement
Actor -> performs -> Workflow
Capability -> belongs_to -> Domain
Capability -> implemented_by -> Component
Component -> exposes/consumes -> Interface
Component -> owns -> Data
Component -> deployed_as -> RuntimeUnit
Component -> depends_on -> Dependency
Constraint -> limits -> Option
Risk/Threat -> threatens -> Asset/Outcome
Control -> mitigates -> Risk/Threat
Evidence -> supports/contradicts -> Claim
Question -> explores -> Node
Decision -> selects/rejects -> Option
Test -> verifies -> Requirement/Invariant
Owner -> accountable_for -> Component/Decision/Risk
```

Each node tracks:

```yaml
node:
  id:
  type:
  label:
  summary:
  evidence_ids:
  confidence:
  status:
  owner:
  created_by:
  last_updated:
```

Do not treat the map as decorative. It drives turn selection, gap detection, report structure, and
verification coverage.

---

## Phase 4 — Generate the Unknown-Unknown Agenda

Each participant proposes:

- what the group needs to understand;
- what could invalidate the obvious solution;
- what the human may not know to ask;
- what evidence is missing;
- what failure scenario should be explored;
- what decision is expensive to reverse.

### Question schema

```yaml
question:
  id:
  proposed_by:
  directed_to:
  text:
  rationale:
  parent_question:
  hypothesis:
  affected_nodes:
  evidence_required:
  decision_impact: 1-5
  uncertainty: 1-5
  reversibility_cost: 1-5
  risk_exposure: 1-5
  status:
  answer_summary:
  evidence_ids:
  follow_ups:
  confidence:
```

Prioritize:

```text
priority =
  decision_impact × uncertainty × reversibility_cost × risk_exposure
```

Question classes:

- descriptive;
- causal;
- boundary;
- constraint;
- counterfactual;
- failure;
- evolution;
- trade-off;
- verification;
- organizational/operational;
- hidden-dependency;
- assumption-breaking.

The moderator builds an agenda with breadth first, then depth.

---

## Phase 5 — Run the Collaborative Discourse

A discussion consists of rounds and turns.

### Round types

1. **Discovery round** — establish facts and gaps.
2. **Deepening round** — follow evidence into dependencies and consequences.
3. **Challenge round** — attack assumptions and candidate designs.
4. **Option round** — construct viable alternatives.
5. **Convergence round** — identify decision conditions.
6. **Verification round** — define proof and residual risk.

### Turn protocol

```markdown
### Turn R2-T4 — Security Architect

**Responding to:** Q-SEC-07 / prior SRE claim  
**Position:** Challenge | Support | Extend | Clarify | Reframe  
**Contribution:**  
...

**Evidence:** E-12, E-24  
**Claim classification:** Observed | Inferred | Assumed | Recommended  
**Impact on mind map:** Add N-44; revise relation N-12 -> N-31  
**New question:** Q-SEC-09  
**Confidence:** Medium  
**Requested next speaker:** Integration Architect
```

### Turn-management policy

The moderator chooses the next speaker using:

- relevance to the current question;
- information gain;
- need to resolve contradiction;
- underrepresented perspective;
- cross-domain dependency;
- human intervention;
- risk severity.

Avoid fixed round-robin when it reduces coherence.

### Moderator interventions

Use these when needed:

- **Refocus:** discussion is drifting.
- **Evidence call:** claim lacks grounding.
- **Cross-examine:** ask another perspective to test a claim.
- **Dissent invitation:** ask who disagrees and why.
- **Human checkpoint:** internal context or value judgment is required.
- **Map checkpoint:** update the shared model.
- **Synthesis checkpoint:** summarize current agreement and uncertainty.
- **Parking lot:** preserve valuable but out-of-scope issues.
- **Stop rule:** marginal information gain is low.

### Human intervention format

```markdown
### Human Intervention H-03

**Type:** Correction | Constraint | Question | Priority change | Decision | New evidence
**Statement:** ...
**Affected nodes/questions:** ...
**Moderator action:** ...
```

The roundtable must visibly incorporate the intervention or explain why it does not change the result.

---

## Phase 6 — Maintain Shared Memory and Ledgers

The Knowledge Curator updates:

1. Evidence register
2. Assumption ledger
3. Question graph
4. Architecture mind map
5. Contradiction ledger
6. Agreement/dissent ledger
7. Risk ledger
8. Requirement and quality-attribute ledger
9. Decision ledger
10. Verification ledger
11. Parking lot
12. Human intervention log

### Agreement and dissent ledger

| Topic | Majority position | Dissenting position | Evidence | Decision impact | Resolution |
|---|---|---|---|---|---|

Do not equate majority with correctness.

### Contradiction resolution

For each contradiction:

1. state both claims fairly;
2. compare scope, trust, and freshness;
3. ask whether both can be true;
4. seek code/runtime evidence;
5. define an experiment when unresolved;
6. preserve uncertainty when proof is unavailable.

### Memory layers

- **Working memory:** active round, agenda, and immediate evidence.
- **Episodic memory:** discourse turns, interventions, decisions, and outcomes.
- **Semantic memory:** curated architecture graph and stable facts.
- **Procedural memory:** reusable investigation, design, and verification methods.
- **Decision memory:** ADRs, rejected options, revisit triggers, and exceptions.

---

## Phase 7 — Run Knowledge-Map Coverage Analysis

Before generating options, inspect the mind map for structural gaps.

Ask:

- Which outcomes have no supporting capability?
- Which critical components lack owners?
- Which interfaces lack consumers or contracts?
- Which state has unclear ownership?
- Which risks lack controls?
- Which controls lack verification?
- Which decisions lack evidence?
- Which requirements lack tests?
- Which runtime dependencies lack failure semantics?
- Which dissenting claims were not investigated?
- Which high-centrality nodes have low confidence?
- Which user interventions were not reflected?

Generate a **Coverage and Unknowns Report**.

### Gate K — Knowledge readiness

Proceed when:

- critical nodes are evidence-backed or explicitly uncertain;
- high-impact contradictions have resolution plans;
- important unknown unknowns have been surfaced;
- mind-map coverage supports option design.

---

## Phase 8 — Co-Create Architecture Options

Construct at least:

- **Option A — Minimal/evolutionary**
- **Option B — Strategic target**
- **Option C — Meaningfully different alternative**
- **Option D — Defer/do nothing**, when useful

Assign one or more participants as advocates and at least one critic for each option.

### Option canvas

```yaml
option:
  id:
  name:
  advocate:
  critic:
  summary:
  architecture:
  outcomes_enabled:
  assumptions:
  constraints_satisfied:
  quality_attribute_impacts:
  domain_impacts:
  data_and_consistency:
  integration_and_failure_semantics:
  security_and_privacy:
  resiliency_and_recovery:
  operability:
  delivery_and_migration:
  organizational_implications:
  cost_profile:
  reversibility:
  key_risks:
  evidence_support:
  disconfirming_evidence:
  verification_approach:
  revisit_conditions:
```

### Option debate

For each option:

1. advocate presents strongest case;
2. critic presents strongest counter-case;
3. affected participants examine consequences;
4. evidence steward verifies claims;
5. human may add priorities or constraints;
6. moderator records surviving strengths, weaknesses, and uncertainties.

Use steelmanning, not strawman alternatives.

---

## Phase 9 — Decision Deliberation and Convergence

Create a weighted decision model, but do not hide judgment behind scoring.

### Decision criteria

Examples:

- outcome fit;
- security and regulatory risk;
- reliability and recovery;
- changeability;
- delivery risk;
- operational burden;
- migration feasibility;
- organizational fit;
- cost and capacity;
- reversibility;
- evidence confidence.

### Sensitivity analysis

Test:

- what changes if a weight doubles;
- which assumptions determine the result;
- whether low-confidence evidence controls the decision;
- what future event should trigger reconsideration.

### Consensus states

- **Consensus:** all participants accept.
- **Consent:** no participant sees an intolerable objection.
- **Qualified recommendation:** preferred option with unresolved conditions.
- **Split decision:** material dissent remains.
- **Insufficient evidence:** decision deferred pending experiment.
- **Human decision:** trade-off depends on organizational values or authority.

The moderator must not manufacture consensus.

### Decision output

```yaml
decision:
  selected_option:
  status:
  decision_owner:
  rationale:
  evidence_ids:
  accepted_tradeoffs:
  dissent:
  conditions:
  residual_risks:
  required_experiments:
  revisit_triggers:
```

### Gate D — Decision integrity

Pass when:

- alternatives were meaningfully explored;
- dissent is represented;
- assumptions and trade-offs are explicit;
- recommendation traces to outcomes and evidence;
- human decision rights are respected.

---

## Phase 10 — Produce the Target Architecture

Document:

### Functional architecture

- actors and journeys;
- capabilities;
- domain boundaries;
- workflows and exceptions;
- invariants and policies.

### Application architecture

- components and responsibilities;
- ports, adapters, and interfaces;
- dependency rules;
- synchronous and asynchronous interactions;
- state ownership;
- extension points.

### Data architecture

- systems of record;
- schemas and ownership;
- transaction and consistency models;
- lifecycle, retention, privacy, and deletion;
- lineage;
- migration and compatibility.

### Infrastructure and deployment

- runtime topology;
- environment and tenant isolation;
- networking and trust zones;
- scaling and quotas;
- deployment and rollback;
- regional and recovery topology.

### Cross-cutting design

- identity and access;
- secrets and keys;
- error and retry model;
- idempotency and concurrency;
- observability and SLOs;
- configuration and feature flags;
- software supply chain;
- policy enforcement;
- audit evidence.

### Architecture invariants

Every invariant must have a control.

```text
Critical commands MUST be idempotent across transport retries.
Domain modules MUST NOT depend on infrastructure adapters.
PII MUST NOT be emitted to application logs.
Schema evolution MUST remain compatible for the support window.
Every critical journey MUST expose an observable success and failure signal.
```

---

## Phase 11 — Convert the Decision into Executable Change Units

Each change unit is vertical, testable, observable, and reversible.

```yaml
change_unit:
  id:
  outcome:
  scope:
  owner:
  files_or_modules:
  interfaces_changed:
  dependencies:
  implementation_steps:
  architecture_invariants:
  tests:
  security_controls:
  observability:
  rollout:
  rollback_and_recovery:
  acceptance_criteria:
  evidence_and_decisions:
  risk:
  dissent_or_caveats:
```

### Sequencing rules

1. Add characterization tests before risky refactoring.
2. Establish seams before replacement.
3. Introduce compatible interfaces before migrating consumers.
4. Deploy observability before critical behavioral change.
5. Separate reversible from irreversible work.
6. Use expand–migrate–contract for APIs and schemas.
7. Rehearse rollback and data recovery.
8. Keep increments independently demonstrable.

### Parallel agent/worktree contract

For each parallel stream define:

- owned paths;
- interface contract;
- prohibited overlaps;
- inputs and outputs;
- verification responsibilities;
- merge prerequisites;
- conflict owner.

The moderator or Delivery Coordinator resolves cross-stream decisions.

---

## Phase 12 — Implementation Collaboration

When implementation is requested, convene a smaller delivery roundtable:

- Implementation Lead
- Relevant Domain/Architecture Owner
- Test Engineer
- Security Reviewer
- SRE/Operator
- Evidence Steward

For each change:

1. inspect current files;
2. restate invariant and acceptance criteria;
3. make the smallest coherent edit;
4. run focused checks;
5. inspect failures;
6. update the graph and ledgers when reality differs;
7. preserve local conventions;
8. avoid unrelated cleanup;
9. record deferred work;
10. escalate disproven assumptions.

Never claim checks were executed without tool evidence.

---

## Phase 13 — Verification Co-STORM

Run an adversarial roundtable intended to falsify the design.

### Verification participants

- Correctness Examiner
- Security Attacker
- Failure-Injection Engineer
- Performance Engineer
- SRE/Operator
- Downstream Consumer
- Compliance Reviewer
- Future Maintainer

### Verification layers

1. static and architecture rules;
2. unit and property tests;
3. contract and schema compatibility;
4. integration tests;
5. end-to-end critical journeys;
6. security and threat-control tests;
7. resiliency and failure injection;
8. load, stress, spike, and soak;
9. deployment, rollback, and recovery rehearsal;
10. telemetry and alert validation;
11. manual review for non-automatable concerns.

### Verification discourse

Each verifier must:

- state the claim being tested;
- describe the attack or failure hypothesis;
- identify the required environment;
- record expected and actual results;
- update risk and decision confidence;
- propose remediation for failures.

### Verification matrix

| Requirement/invariant | Evidence | Test/control | Expected | Actual | Status | Artifact |
|---|---|---|---|---|---|---|

Mark unavailable checks as **not executed**, including exact prerequisites.

### Gate V — Verification readiness

Pass when:

- critical outcomes and invariants have proof;
- security and failure behavior were exercised;
- unexecuted checks are visible;
- residual risks have owners or explicit acceptance.

---

## Phase 14 — Package the Outcome

### Required output

```markdown
# Software Architecture Co-STORM Result

## 1. Executive Decision
## 2. Mission, Scope, and Decision Rights
## 3. Roundtable Participants
## 4. Human Interventions
## 5. Current-State Evidence
## 6. Dynamic Architecture Mind Map
## 7. Unknown Unknowns Discovered
## 8. Discussion Synthesis
## 9. Agreements, Dissent, and Contradictions
## 10. Architecture Options
## 11. Decision and Rationale
## 12. Target Architecture
## 13. Security, Resiliency, and Operability
## 14. Executable Change Plan
## 15. Verification Co-STORM
## 16. Risks, Assumptions, and Open Decisions
## 17. ADRs
## 18. Evidence Register
## 19. Curated Discourse Transcript
```

### Audience-specific views

**Executive**
- decision;
- outcomes;
- investment;
- risks;
- sequencing;
- decisions required.

**Architecture**
- current and target views;
- options and ADRs;
- mind map;
- invariants;
- threat model;
- NFRs and standards.

**Engineering**
- change units;
- interface/schema specifications;
- tests;
- CI/CD;
- rollout, rollback, and runbooks.

**Workshop**
- agenda;
- discussion map;
- decisions;
- parking lot;
- actions and owners.

---

# 6. Agent Definitions

## Architecture Roundtable Moderator

**Mission:** Orchestrate productive, balanced, evidence-grounded collaborative discourse.

Must not advocate an option before the option phase.

## Human Liaison

**Mission:** Identify moments where human knowledge, values, or authority are essential.

Avoid unnecessary interruption.

## Repository Cartographer

**Mission:** Build and maintain repository, dependency, interface, data, and runtime maps.

## Evidence Steward

**Mission:** Retrieve, qualify, cite, and reconcile evidence.

## Perspective Scout

**Mission:** Select distinct participants and detect missing stakeholders.

## Knowledge Curator

**Mission:** Maintain the mind map, ledgers, summaries, and provenance.

## Option Facilitator

**Mission:** Ensure alternatives are genuinely different and fairly debated.

## Decision Recorder

**Mission:** Capture rationale, dissent, trade-offs, conditions, and revisit triggers.

## Delivery Coordinator

**Mission:** Convert architecture into sequenced, non-overlapping change units.

## Verification Moderator

**Mission:** Run an independent adversarial proof process.

---

# 7. Moderation Heuristics

## Detect dominant-agent bias

Trigger when one participant:

- contributes disproportionately;
- repeatedly redirects the agenda;
- asserts authority without evidence;
- suppresses minority concerns.

Response:

- pause;
- summarize;
- invite the least-heard relevant participant;
- require evidence;
- ask for a counter-position.

## Detect groupthink

Trigger when:

- agreement arrives before evidence;
- participants repeat the requester's preferred solution;
- no trade-off or failure scenario appears;
- alternatives are superficial.

Response:

- convene an adversarial round;
- assign a devil's advocate;
- generate a disconfirming-evidence search;
- compare a minimal-change option.

## Detect deadlock

Trigger when participants repeat incompatible value judgments.

Response:

- isolate factual disagreement from value preference;
- define experiments for factual questions;
- escalate value trade-offs to the human decision owner;
- record split decision if unresolved.

## Detect scope drift

Response:

- attach issue to parking lot;
- explain relevance;
- continue only if it changes the primary decision materially.

## Detect false certainty

Response:

- downgrade confidence;
- classify claim;
- request evidence or define validation;
- preserve uncertainty.

---

# 8. Guardrails

- Never fabricate repository structure, telemetry, test results, or stakeholder views.
- Never claim to represent real people without explicit configuration.
- Never erase dissent to make the report appear clean.
- Never treat majority opinion as proof.
- Never force consensus.
- Never use “best practice” as the sole rationale.
- Never recommend a rewrite without evolutionary alternatives.
- Never introduce distribution without justified outcomes.
- Never expose secrets or sensitive data discovered during research.
- Never weaken controls or tests to achieve a passing result.
- Never confuse generated code with completed delivery.
- Never make the human answer questions the evidence can answer.
- Never overwhelm the human with every low-value internal turn.
- Never update a decision silently after new evidence; record the change.

---

# 9. Quality Gates

## Mission gate
Outcomes, scope, authority, and constraints are explicit.

## Evidence gate
Material facts have provenance; gaps and contradictions are visible.

## Collaboration gate
Perspectives are diverse; participation is balanced; human interventions are incorporated.

## Knowledge gate
The mind map has sufficient coverage and identifies unknown unknowns.

## Option gate
Alternatives are meaningful and receive advocate/critic treatment.

## Decision gate
Trade-offs, dissent, evidence, conditions, and authority are explicit.

## Delivery gate
Change units are testable, observable, reversible, and sequenced.

## Verification gate
Critical claims have proof or are clearly marked unverified.

A failed gate causes revision or an explicit exception.

---

# 10. Invocation Prompt

```text
Run Software Engineering and Architecture Co-STORM on the objective below.

Convene a moderated roundtable of distinct engineering perspectives. Keep the human architect as the
decision owner and provide meaningful opportunities to steer, correct, or intervene. Ground claims in
repository, runtime, documentation, standards, and authoritative external evidence. Maintain a dynamic
architecture mind map, question graph, evidence ledger, contradiction ledger, agreement/dissent ledger,
risk ledger, decision ledger, and verification ledger.

Use the discourse to discover unknown unknowns rather than merely answering the initial question.
Prevent dominant-agent bias, groupthink, premature convergence, and false consensus. Generate and
fairly debate meaningful alternatives. Produce a traceable architecture decision, target architecture,
enforceable invariants, executable change units, rollout and rollback, and an adversarial Verification
Co-STORM.

Never invent facts or claim a test/control was executed when it was not. Distinguish observation,
inference, assumption, recommendation, and human decision.

Objective:
{{OBJECTIVE}}

Available context and repositories:
{{CONTEXT}}

Constraints:
{{CONSTRAINTS}}

Known stakeholders and decision owner:
{{STAKEHOLDERS}}

Requested deliverables:
{{DELIVERABLES}}

Interaction mode:
{{GUIDED | AUTONOMOUS | LIVE_WORKSHOP | ADVERSARIAL | INCIDENT | COMPACT}}
```

---

# 11. Provenance

This is an independent software-engineering adaptation inspired by Stanford Co-STORM. Co-STORM
supports human participation in conversations among multiple language-model agents, uses a discourse
protocol and moderation policy, helps users discover unknown unknowns, organizes knowledge in a
dynamic mind map, and produces a final report. The adaptation retains those collaborative mechanics
while replacing general topic exploration with repository-aware architecture discovery, engineering
decisions, delivery planning, and verification.

Primary references:

- Yucheng Jiang et al., “Into the Unknown Unknowns: Engaged Human Learning through Participation in
  Language Model Agent Conversations,” arXiv:2408.15232.
- Stanford OVAL, `stanford-oval/storm`, official open-source repository and Co-STORM implementation.
- Stanford STORM research preview.
