# Example: Plugin Marketplace Architecture Co-STORM

## Mission

Design an internal coding-agent plugin marketplace that allows developers to publish and install
plugins while preventing malicious, vulnerable, unauthorized, or noncompliant plugins from entering
enterprise environments.

## Roundtable

- Human decision owner
- Product Outcome Strategist
- Platform Architect
- Security Architect
- Supply-Chain Security Engineer
- SRE
- Developer-Experience Lead
- Compliance Architect
- Red-Team Attacker
- Moderator

## Unknown unknown discovered

The initial request focused on pre-publication scanning. The roundtable surfaced that scanner approval
does not control runtime behavior after installation, especially when a plugin can fetch remote code,
invoke tools, access credentials, or change after approval.

## Mind-map delta

```text
Plugin -> has -> ImmutableArtifactDigest
Publisher -> signs -> PluginVersion
PluginVersion -> requests -> Capability
Policy -> grants/denies -> Capability
ScannerResult -> evaluates -> PluginVersion
Approval -> binds_to -> ImmutableArtifactDigest
RuntimeSandbox -> enforces -> GrantedCapability
Revocation -> disables -> PluginVersion/Publisher
Telemetry -> observes -> RuntimeBehavior
```

## Option discussion

### A — Scan and manually approve
Low implementation cost, but weak runtime controls and revocation.

### B — Signed immutable packages plus layered scanning
Improves provenance and integrity, but still assumes trusted execution.

### C — Signed packages, policy-scoped capabilities, sandboxing, runtime telemetry, and revocation
Best risk-adjusted target for untrusted community contributions, but higher platform cost.

## Qualified recommendation

Select C for broadly publishable plugins; permit a reduced B path only for centrally owned,
low-capability plugins under explicit policy.

## Dissent

The Developer-Experience Lead objects to a high-friction permission model. The decision retains the
objection and requires capability presets, transparent diagnostics, and approval SLOs.

## Verification examples

- reject a package whose signature does not match its publisher;
- prove approval is bound to the scanned digest;
- block undeclared network and filesystem access;
- simulate a malicious post-install callback;
- revoke a package and verify new and existing installs are disabled;
- test scanner and policy-engine outage behavior;
- verify audit evidence is immutable and queryable.
