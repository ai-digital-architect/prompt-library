# Software Engineering and Architecture Co-STORM Skill

A portable human–AI collaborative architecture skill inspired by Stanford Co-STORM.

It does more than assign several agents to produce independent reports. It runs a moderated
architecture discourse, allows the human architect to steer, maintains a live knowledge map, surfaces
unknown unknowns, preserves dissent, and turns the result into architecture decisions and verified
delivery plans.

## Package

```text
software-architecture-co-storm-skill/
├── SKILL.md
├── README.md
├── references/
│   ├── participant-catalog.md
│   ├── moderation-protocol.md
│   ├── knowledge-map-schema.md
│   └── integration-guide.md
├── templates/
│   ├── mission-and-roundtable.md
│   ├── discourse-turn.md
│   ├── mind-map.md
│   ├── decision-and-dissent.md
│   ├── change-unit.md
│   └── verification-matrix.md
├── examples/
│   └── example-architecture-session.md
└── evals/
    └── eval-cases.md
```

## Suggested canonical placement

```text
.ai/
└── skills/
    └── software-architecture-co-storm/
```

Create vendor-specific wrappers in `.claude`, `.github`, `.codex`, `.cursor`, or another coding-agent
configuration, while retaining this package as the canonical methodology.

## Primary distinction from the previous STORM skill

| Architecture STORM | Architecture Co-STORM |
|---|---|
| Multi-perspective investigation | Moderated multi-party discourse |
| Human mainly provides context | Human observes, steers, corrects, and decides |
| Outline and synthesis are central | Evolving knowledge map and discourse are central |
| Investigator-to-evidence Q&A | Participant-to-participant questioning and challenge |
| Findings are curated | Agreements, dissent, interventions, and contradictions are curated |
| Verification pass | Independent adversarial Verification Co-STORM |

## Minimum host capabilities

- repository/file search;
- code navigation;
- optional web or documentation retrieval;
- persistent artifact writing;
- optional subagents;
- optional graph or structured-memory storage;
- command execution for implementation and verification.

A single model can emulate the roles sequentially, but the transcript must still preserve distinct
perspectives and moderation behavior.
