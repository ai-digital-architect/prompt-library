# Host Integration Guide

## Claude Code

Use `SKILL.md` as the canonical skill entry. Create specialized subagents for moderator, cartographer,
security, SRE, curator, and verifier when the host supports them. Store the knowledge map and
transcripts in repository files.

## GitHub Copilot

Reference the skill from repository custom instructions and custom agents. Use prompt files for
specific modes such as `architecture-workshop`, `adversarial-review`, and `verification-co-storm`.

## Codex and other coding agents

Expose the skill as repository instructions plus reusable templates. A single agent may execute roles
sequentially, but it must preserve turn attribution and disagreement.

## MCP/tool integration

Useful tool categories:

- source-code search and symbol graph;
- Git history and ownership;
- documentation retrieval;
- issue and incident retrieval;
- API/schema catalogs;
- dependency and vulnerability scanning;
- CI/CD results;
- telemetry and SLO query;
- policy and control catalogs;
- graph storage and visualization.

## Suggested hooks

### Pre-discussion
- validate mission artifact;
- inventory repository;
- redact secrets;
- initialize ledgers.

### After each round
- validate evidence references;
- update map;
- detect uncovered critical perspectives;
- snapshot transcript.

### Pre-decision
- enforce alternative count;
- run dissent and sensitivity checks;
- verify decision authority.

### Pre-completion
- enforce verification disclosure;
- ensure change units have rollback;
- validate links among decisions, evidence, tests, and risks.
