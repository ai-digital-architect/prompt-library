# Dynamic Architecture Knowledge Map

## JSON-like schema

```yaml
knowledge_map:
  metadata:
    mission_id:
    version:
    updated_at:
    updated_by:
  nodes:
    - id:
      type:
      label:
      summary:
      attributes:
      evidence_ids:
      confidence:
      status:
      owner:
      created_in_turn:
      updated_in_turn:
  edges:
    - id:
      source:
      relation:
      target:
      attributes:
      evidence_ids:
      confidence:
  unresolved:
    - question_id:
      affected_nodes:
      impact:
  history:
    - version:
      turn:
      change_summary:
```

## Recommended node types

Outcome, Stakeholder, Actor, Capability, Domain, Workflow, Requirement, QualityAttribute, Constraint,
Component, Interface, Event, Data, RuntimeUnit, Dependency, TrustBoundary, FaultDomain, Risk, Threat,
Control, Evidence, Assumption, Question, Option, Decision, Test, Owner, Incident, Metric, SLO.

## Useful graph queries

- outcomes without requirements;
- requirements without implementation;
- components without owners;
- interfaces without contracts or consumers;
- data without owners or retention;
- threats without controls;
- controls without tests;
- decisions without evidence;
- risks without mitigations;
- critical paths with low-confidence nodes;
- high-centrality dependencies without failure handling;
- dissent attached to accepted decisions;
- human interventions not reflected in the current graph.

## Storage options

### File-native

```text
architecture/
├── knowledge-map.yaml
├── evidence.yaml
├── questions.yaml
├── decisions/
├── risks.yaml
└── transcripts/
```

### Graph database

Map node and edge types into Neo4j, Neptune, or another property graph when cross-repository scale,
querying, or visualization justifies it.

File-native storage remains the source of truth unless the repository explicitly establishes another
authority.
