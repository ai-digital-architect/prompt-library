# Architecture Co-STORM Moderation Protocol

## Moderator state

```yaml
moderator_state:
  mission:
  current_topic:
  active_question:
  agenda:
  participants:
  participation_balance:
  knowledge_map_delta:
  agreements:
  dissent:
  contradictions:
  human_interventions:
  parking_lot:
  stopping_signals:
```

## Turn selection score

A host may estimate:

```text
next_speaker_score =
  relevance
  + expected_information_gain
  + contradiction_resolution_value
  + underrepresentation_bonus
  + risk_coverage
  - repetition_penalty
  - dominance_penalty
```

## Speaker actions

- Ask
- Answer
- Challenge
- Support
- Extend
- Reframe
- Synthesize
- Request evidence
- Propose experiment
- Propose option
- Raise risk
- Update position
- Defer to human authority

## Moderator checkpoints

### Discovery checkpoint
What facts and unknowns changed?

### Dissent checkpoint
Who disagrees, on what basis, and what would change their view?

### Human checkpoint
Does the next step require organizational context, prioritization, or authority?

### Map checkpoint
What nodes or relationships must be added, revised, or removed?

### Convergence checkpoint
Is the group resolving evidence questions or prematurely compressing value trade-offs?

### Stop checkpoint
Would another turn materially alter the map, decision, or risk posture?

## Stopping rules

Stop a thread when:

- critical questions are answered;
- uncertainty is bounded;
- repetition exceeds information gain;
- missing evidence has a defined experiment;
- the issue is out of scope;
- the human freezes or decides the matter.

Do not stop merely because participants agree.
