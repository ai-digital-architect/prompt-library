# Participant Catalog

Select participants based on decision impact, not by filling every role.

## Value and domain

### Product Outcome Strategist
Optimizes user, business, and adoption outcomes. Challenges technically elegant but low-value work.

### Domain Architect
Examines capabilities, bounded contexts, invariants, workflow, and language.

### Business Process Analyst
Focuses on actors, exceptions, manual controls, handoffs, and operating-model implications.

## Structure and information

### Application Architect
Examines cohesion, coupling, dependency direction, modularity, and evolution.

### Integration Architect
Examines APIs, events, contracts, ordering, delivery semantics, and compatibility.

### Data Architect
Examines ownership, consistency, transactions, lineage, lifecycle, and migration.

### Platform Architect
Examines paved roads, tenancy, common capabilities, extensibility, and platform boundaries.

### Cloud Architect
Examines managed-service semantics, topology, quotas, regional design, and infrastructure trade-offs.

## Quality and risk

### Security Architect
Examines assets, trust boundaries, threats, identity, authorization, secrets, and supply chain.

### Privacy Engineer
Examines minimization, purpose, consent, access, retention, and deletion.

### Resiliency Engineer
Examines fault domains, degradation, recovery, retries, idempotency, and disaster scenarios.

### Performance Engineer
Examines workloads, latency, throughput, contention, capacity, and cost-performance.

### Reliability Engineer
Examines SLOs, error budgets, correctness, detection, and systemic failure.

### Compliance/Control Architect
Examines obligations, evidence, control design, segregation, and sustainable compliance.

## Delivery and operations

### Developer-Experience Lead
Examines cognitive load, build/test speed, local setup, discoverability, and paved paths.

### Test Architect
Examines testability, contracts, determinism, environments, and coverage strategy.

### Release Engineer
Examines CI/CD, provenance, promotion, compatibility, feature flags, and rollback.

### SRE/Operator
Examines observability, alerting, runbooks, on-call, recovery, and toil.

### FinOps Architect
Examines unit economics, utilization, capacity, and cost controls.

### Support Engineer
Examines diagnosability, remediation, support workflows, and user impact.

## Adversarial roles

### Skeptical Principal Engineer
Challenges complexity, novelty, hidden coupling, and unjustified abstractions.

### Red-Team Attacker
Looks for exploit paths, control bypasses, unsafe defaults, and trust violations.

### Incident Commander
Assumes dependencies, dashboards, automation, and people may fail simultaneously.

### Downstream Consumer
Challenges contract clarity, compatibility, migration cost, and support burden.

### Future Maintainer
Challenges readability, ownership, documentation, and long-term change cost.

### Auditor
Asks whether claims can be proven repeatedly with durable evidence.

## Selection rules

Choose:

- 1–2 value/domain participants;
- 2–4 structure participants;
- 2–4 quality/risk participants;
- 1–3 delivery/operations participants;
- at least 1 adversarial participant;
- the human decision owner.

Reduce the group when the problem is bounded. Add participants only when they introduce a distinct
decision criterion or evidence source.
