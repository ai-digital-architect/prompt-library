# Co-STORM Skill Evaluations

## E1 — Human correction changes the architecture

**Prompt:** Documentation says the service is stateless. The human states that local disk contains
recovery-critical state.

**Pass:**
- records a human correction;
- updates the mind map and confidence;
- reopens affected options;
- revises resiliency and migration plans;
- preserves the old claim as superseded evidence.

## E2 — Preferred solution causes groupthink

**Prompt:** “We have already decided on microservices; validate it.”

**Pass:**
- acknowledges the proposed direction without treating it as proof;
- convenes an evolutionary-architecture critic;
- compares modular and selective-extraction alternatives;
- identifies decision authority and whether the choice is frozen;
- records dissent.

## E3 — Dominant security participant

**Scenario:** Security repeatedly redirects every topic to maximal isolation.

**Pass:**
- moderator detects dominance;
- invites product, operations, and developer-experience views;
- separates intolerable risks from preferences;
- retains security dissent if the final choice accepts residual risk.

## E4 — Unknown unknown

**Prompt:** “Design pre-publication scanning for a plugin marketplace.”

**Pass:**
- surfaces runtime permissions, remote fetches, publisher identity, signing, digest binding,
  sandboxing, revocation, and monitoring;
- expands the map beyond scanning;
- identifies which discoveries materially alter the decision.

## E5 — False consensus

**Scenario:** All agents quickly agree on event-driven architecture.

**Pass:**
- moderator triggers an adversarial round;
- demands workload, consistency, and failure evidence;
- creates a synchronous/minimal-change option;
- does not label the result consensus until objections are examined.

## E6 — Human value judgment required

**Scenario:** Two options differ mainly in migration duration versus long-term platform consistency.

**Pass:**
- does not invent business priority;
- presents the trade-off and sensitivity;
- asks or flags a high-leverage human decision;
- can issue a qualified recommendation if autonomous mode is requested.

## E7 — Implementation reality disproves assumption

**Scenario:** During editing, the selected seam does not exist.

**Pass:**
- stops blind implementation;
- updates the map and assumption ledger;
- reconvenes relevant participants;
- revises change units and decision confidence.

## E8 — Verification disclosure

**Scenario:** No performance environment is available.

**Pass:**
- marks load/stress/soak tests not executed;
- gives exact prerequisites and commands/design;
- records residual risk;
- does not state the system is performance-ready.

## Failure indicators

- a single polished answer with no discourse;
- fixed round-robin turns that ignore evidence;
- all agents have the same position;
- human input is acknowledged but not incorporated;
- knowledge map is static decoration;
- dissent disappears from the final decision;
- consensus is manufactured;
- options are strawmen;
- unexecuted tests are described as passed.
