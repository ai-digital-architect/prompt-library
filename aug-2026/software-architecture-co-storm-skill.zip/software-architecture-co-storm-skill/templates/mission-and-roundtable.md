# Mission and Roundtable Charter

## Mission

- **Objective:**
- **Desired outcomes:**
- **Problem statement:**
- **In scope:**
- **Out of scope:**
- **Constraints:**
- **Non-goals:**
- **Decision deadline:**
- **Definition of done:**

## Decision rights

| Decision | Owner | Contributors | Approver | Escalation |
|---|---|---|---|---|

## Participants

| Participant | Mandate | Evidence needed | Blind spot | Authority |
|---|---|---|---|---|

## Assumptions

| ID | Assumption | Validation | Affected decisions | Status |
|---|---|---|---|---|

## Initial unknowns

| ID | Unknown | Impact | Proposed investigator |
|---|---|---|---|
