# Executable Change Unit

- **ID:**
- **Outcome:**
- **Owner:**
- **Risk:**
- **Dependencies:**
- **ADR/evidence links:**
- **Relevant dissent:**

## Scope

## Files/modules

## Interfaces/schemas

## Implementation steps

## Architecture invariants

## Tests

## Security controls

## Observability

## Rollout

## Rollback and recovery

## Acceptance criteria

## Parallel-work contract

- Owned paths:
- Prohibited overlaps:
- Inputs:
- Outputs:
- Merge prerequisites:
- Conflict owner:

## Deferred work
