# Verification Co-STORM Matrix

| ID | Claim/requirement/invariant | Challenger | Failure hypothesis | Test/control | Environment | Expected | Actual | Status | Artifact |
|---|---|---|---|---|---|---|---|---|---|

## Verification discourse findings

### Correctness

### Security

### Resiliency

### Performance

### Operability

### Compatibility

### Maintainability

### Compliance

## Unexecuted verification

| Check | Why not executed | Exact prerequisite | Residual risk | Owner |
|---|---|---|---|---|

## Decision-confidence update

- Prior confidence:
- New evidence:
- Updated confidence:
- Decision impact:
