# Co-STORM Discourse

## Round

- **Round ID:**
- **Type:** discovery | deepening | challenge | option | convergence | verification
- **Active question:**
- **Round objective:**

## Turn

- **Turn ID:**
- **Speaker:**
- **Responding to:**
- **Position:** ask | support | challenge | extend | clarify | reframe | synthesize

### Contribution

### Evidence

### Claim classification

Observed | Inferred | Assumed | Recommended | Human decision

### Mind-map delta

### New question or experiment

### Confidence

### Requested next speaker

## Moderator checkpoint

- **What changed:**
- **Agreement:**
- **Dissent:**
- **Contradictions:**
- **Human input needed:**
- **Next question:**
- **Parking lot:**
