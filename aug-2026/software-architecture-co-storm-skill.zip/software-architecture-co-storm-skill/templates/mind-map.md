# Architecture Mind Map Snapshot

- **Mission:**
- **Version:**
- **Round/turn:**
- **Updated by:**

## Nodes

| ID | Type | Label | Summary | Evidence | Confidence | Owner | Status |
|---|---|---|---|---|---|---|---|

## Relationships

| ID | Source | Relation | Target | Evidence | Confidence |
|---|---|---|---|---|---|

## Map changes

| Change | Reason | Turn | Affected decisions |
|---|---|---|---|

## Coverage gaps

| Gap | Impact | Question/experiment | Owner |
|---|---|---|---|
