# Collaborative Architecture Decision

- **Decision ID:**
- **Title:**
- **Status:** consensus | consent | qualified | split | deferred | human-decision
- **Decision owner:**
- **Date:**
- **Evidence IDs:**
- **Affected map nodes:**

## Context

## Decision criteria

## Options

### Option A

### Option B

### Option C

## Deliberation summary

## Decision

## Rationale

## Accepted trade-offs

## Dissent

| Participant | Objection | Evidence | Intolerable? | Resolution/condition |
|---|---|---|---|---|

## Conditions and experiments

## Consequences

## Residual risks

## Verification

## Revisit triggers
